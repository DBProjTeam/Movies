package ua.nure.bobrov.SummaryTask4.enums;

/**
 * Role enum
 * 
 * @author Bobrov Vyacheslav
 */
public enum RoleType {

	ADMIN, MANAGER, CLIENT;

	public static RoleType getRoleType(int roleId) {
		if (roleId < 0 || roleId >= RoleType.values().length) {
			return null;
		}
		return RoleType.values()[roleId];
	}

	public String getName() {
		return this.toString().toLowerCase();
	}
}
