package ua.nure.bobrov.SummaryTask4.database.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.bean.CoachSeatsBean;
import ua.nure.bobrov.SummaryTask4.database.DBConnector;
import ua.nure.bobrov.SummaryTask4.database.Field;
import ua.nure.bobrov.SummaryTask4.database.entity.Route;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;

/**
 * Interacts with database. Operates Route data
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class RouteDAO {

	private static final Logger LOG = Logger.getLogger(CoachDAO.class);

	private static final String GET_ALL_ROUTES = "SELECT * FROM route";
	private static final String CREATE_ROUTE = "INSERT INTO route(id_begin_station, id_end_station, begin_time, end_time) VALUES(?,?,?,?)";
	private static final String UPDATE_ROUTE = "UPDATE route SET id_begin_station=?, id_end_station=?, begin_time=?, end_time=? WHERE id_route=?";
	private static final String DELETE_ROUTE = "DELETE FROM route WHERE id_route=?";
	private static final String GET_ROUTE_BY_PK = "SELECT * FROM route WHERE id_route=?";

	private static final String GET_ROUTE_BY_ATTRIBUTES = "SELECT * FROM route WHERE id_begin_station=? AND id_end_station=? AND begin_time=? AND end_time=?";

	private static final String GET_ROUTE_STATISTICS = "SELECT route.id_route, coach.id_coachtype, count(id_ticket)"
			+ "FROM ((route INNER JOIN trip ON route.id_route = trip.id_route) "
			+ "INNER JOIN ticket ON trip.id_trip=ticket.id_trip) INNER JOIN coach ON (ticket.coach_number=coach.number AND trip.id_train=coach.id_train) GROUP BY id_route, id_coachtype";

	private Connection connection;

	/**
	 * Gets Route List from database
	 * 
	 * @return Route List
	 * @throws DatabaseException
	 */
	public Map<Integer, List<CoachSeatsBean>> getStatistics() throws DatabaseException {
		Statement statement = null;
		ResultSet resultSet = null;
		Map<Integer, List<CoachSeatsBean>> map = new HashMap<Integer, List<CoachSeatsBean>>();
		try {
			connection = DBConnector.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(GET_ROUTE_STATISTICS);
			while (resultSet.next()) {
				System.out.println(resultSet.getInt(1) + " " + resultSet.getInt(2) + " " + resultSet.getInt(3));
				if(map.containsKey(resultSet.getInt(1))) {
					map.get(resultSet.getInt(1)).add(new CoachSeatsBean(resultSet.getInt(2), resultSet.getInt(3)));
				} else {
					List<CoachSeatsBean> list = new ArrayList<>();
					list.add(new CoachSeatsBean(resultSet.getInt(2), resultSet.getInt(3)));
					map.put(resultSet.getInt(1), list);
				}
			}
		} catch (SQLException ex) {
			LOG.error(ex.getMessage(), ex);
			throw new DatabaseException(ex.getMessage(), ex);
		} finally {
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return map;
	}
	
	public List<Route> findAll() throws DatabaseException {
		List<Route> routeList = new ArrayList<Route>();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(GET_ALL_ROUTES);
			while (resultSet.next()) {
				routeList.add(extract(resultSet));
			}
		} catch (SQLException ex) {
			LOG.error(ex.getMessage(), ex);
			throw new DatabaseException(ex.getMessage(), ex);
		} finally {
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return routeList;
	}

	/**
	 * Inserts new route in the database
	 * 
	 * @param route
	 *            route to insert
	 * @throws DatabaseException
	 */
	public void insert(Route route) throws DatabaseException {
		PreparedStatement statement = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(CREATE_ROUTE);
			statement.setInt(1, route.getBeginStation().getId());
			statement.setInt(2, route.getEndStation().getId());
			statement.setTime(3, route.getBeginTime());
			statement.setTime(4, route.getEndTime());
			statement.executeUpdate();
		} catch (SQLException ex) {
			LOG.error(ex.getMessage(), ex);
			throw new DatabaseException(ex.getMessage(), ex);
		} finally {
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
	}

	/**
	 * Update route in the database
	 * 
	 * @return true if route was updated, false otherwise
	 * @param route
	 *            route to update
	 * @throws DatabaseException
	 */
	public boolean update(Route route) throws DatabaseException {
		PreparedStatement statement = null;
		boolean isUpdated = false;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(UPDATE_ROUTE);
			statement.setInt(1, route.getBeginStation().getId());
			statement.setInt(2, route.getEndStation().getId());
			statement.setTime(3, route.getBeginTime());
			statement.setTime(4, route.getEndTime());
			statement.setInt(5, route.getId());
			if (statement.executeUpdate() != 0) {
				isUpdated = true;
			}
		} catch (SQLException ex) {
			LOG.error(ex.getMessage(), ex);
			throw new DatabaseException(ex.getMessage(), ex);
		} finally {
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return isUpdated;

	}

	/**
	 * Delete route from database
	 * 
	 * @param pk
	 *            primary key of the route
	 * @return true if route was deleted, false otherwise
	 * @throws DatabaseException
	 */
	public boolean delete(int pk) throws DatabaseException {
		PreparedStatement statement = null;
		boolean isDeleted = false;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(DELETE_ROUTE);
			statement.setInt(1, pk);
			if (statement.executeUpdate() != 0) {
				isDeleted = true;
			}
		} catch (SQLException ex) {
			LOG.error(ex.getMessage(), ex);
		} finally {
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return isDeleted;
	}

	/**
	 * Gets route from database by its primary key
	 * 
	 * @param pk
	 *            primary key of route
	 * @return Route object
	 * @throws DatabaseException
	 */
	public Route getByPK(int pk) throws DatabaseException {
		PreparedStatement statment = null;
		ResultSet resultSet = null;
		Route route = null;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(GET_ROUTE_BY_PK);
			statment.setInt(1, pk);
			resultSet = statment.executeQuery();
			if (resultSet.next()) {
				route = extract(resultSet);
			}
		} catch (SQLException ex) {
			LOG.error(ex.getMessage(), ex);
			throw new DatabaseException(ex.getMessage(), ex);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return route;
	}

	/**
	 * Checks if route is already in database
	 * 
	 * @param route
	 *            route to check
	 * @return true if route is already in database, false otherwise
	 * @throws DatabaseException
	 */
	public boolean exists(Route route) throws DatabaseException {
		PreparedStatement statment = null;
		ResultSet resultSet = null;
		boolean isExist = false;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(GET_ROUTE_BY_ATTRIBUTES);
			statment.setInt(1, route.getBeginStation().getId());
			statment.setInt(2, route.getEndStation().getId());
			statment.setTime(3, route.getBeginTime());
			statment.setTime(4, route.getEndTime());
			resultSet = statment.executeQuery();
			if (resultSet.next()) {
				isExist = true;
			}
		} catch (SQLException ex) {
			LOG.error(ex.getMessage(), ex);
			throw new DatabaseException(ex.getMessage(), ex);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return isExist;
	}

	/**
	 * Extracts a Route object from the result set
	 * 
	 * @param resultSet
	 *            Result set from which the route will be extracted.
	 * @return Route object
	 * @throws SQLException
	 * @throws DatabaseException
	 */
	private Route extract(ResultSet resultSet) throws SQLException, DatabaseException {
		Route route = new Route();
		StationDAO stationDAO = new StationDAO();
		route.setId(resultSet.getInt(Field.ROUTE_ID));
		route.setBeginStation(stationDAO.getByPK(resultSet.getInt(Field.BEGIN_STATION_ID)));
		route.setEndStation(stationDAO.getByPK(resultSet.getInt(Field.END_STATION_ID)));
		route.setBeginTime(resultSet.getTime(Field.BEGIN_TIME));
		route.setEndTime(resultSet.getTime(Field.END_TIME));
		return route;
	}
}
