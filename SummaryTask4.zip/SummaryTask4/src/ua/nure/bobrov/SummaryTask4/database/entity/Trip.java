package ua.nure.bobrov.SummaryTask4.database.entity;

import java.sql.Date;

/**
 * Trip entity
 * 
 * @author Bobrov Vyacheslav
 */
public class Trip extends Entity{
	
	private static final long serialVersionUID = -2127513223836726803L;
	
	private int trainId;
	private int routeId;
	private Date departureDate;	
	
	public int getTrainId() {
		return trainId;
	}
	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}
	public int getRouteId() {
		return routeId;
	}
	public void setRouteId(int routeId) {
		this.routeId = routeId;
	}
	public Date getDepartureDate() {
		return new Date(departureDate.getTime());
	}
	public void setDepartureDate(Date departureDate) {
		this.departureDate = new Date(departureDate.getTime());
	}
	
}
