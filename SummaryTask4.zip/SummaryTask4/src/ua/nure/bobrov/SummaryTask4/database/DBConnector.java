package ua.nure.bobrov.SummaryTask4.database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;

/**
 * Works with MySQL database, provides pooled connection
 * 
 * @author Bobrov Vyacheslav
 *
 */
public final class DBConnector {

	private static final Logger LOG = Logger.getLogger(DBConnector.class);

	private static DataSource datasource;
	private static InitialContext ctx;

	private DBConnector() {

	}

	/**
	 * Returns a database connection from the Pool Connections.
	 * 
	 * @return database connection
	 * @throws SQLException
	 * @throws DatabaseException
	 */
	public static synchronized Connection getConnection() throws SQLException, DatabaseException {
		if (datasource == null) {
			try {
				ctx = new InitialContext();
				Context context = (Context) ctx.lookup("java:comp/env");
				datasource = (DataSource) context.lookup("jdbc/root");
			} catch (NamingException e) {
				LOG.error(e.getMessage(), e);
				throw new DatabaseException(e.getMessage(), e);
			}
		}
		return datasource.getConnection();
	}

	/**
	 * Closes connection
	 * 
	 * @param connection
	 *            connection to close
	 */
	public static void closeConnection(Connection connection) {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				LOG.error(e.getMessage(), e);
			}
		}
	}
	
	/**
	 * Closes statement
	 * 
	 * @param statement
	 *            statement to close
	 */
	public static void closeStatement(Statement statement) {
		if (statement != null) {
			try {
				statement.close();
			} catch (SQLException e) {
				LOG.error(e.getMessage(), e);
			}
		}
	}

	/**
	 * Closes result set
	 * 
	 * @param resultSet
	 *            result set to close
	 */
	public static void closeResultSet(ResultSet resultSet) {
		if (resultSet != null) {
			try {
				resultSet.close();
			} catch (SQLException e) {
				LOG.error(e.getMessage(), e);
			}
		}
	}
	
	/**
	 * Rollbacks a connection
	 * @param connection
	 */
	public static void rollback(Connection connection) {
		if (connection != null) {
			try {
				connection.rollback();
			} catch (SQLException e) {
				LOG.error(e.getMessage(), e);
			}
		}
	}

}
