package ua.nure.bobrov.SummaryTask4.database.entity;


import java.sql.Timestamp;

/**
 * Ticket entity
 * 
 * @author Bobrov Vyacheslav
 */
public class Ticket extends Entity{

	private static final long serialVersionUID = -9023738297979640456L;
	
	private int tripId;
	private int userId;
	private int departureStationId;
	private int arrivalStationId;
	private int coachTypeId;	
	private int coachNumber;
	private int seatNumber;
	private Timestamp departureDate;
	private Timestamp arrivalDate;
	private double price;
	
	public int getCoachTypeId() {
		return coachTypeId;
	}
	public void setCoachTypeId(int coachTypeId) {
		this.coachTypeId = coachTypeId;
	}
	public int getDepartureStationId() {
		return departureStationId;
	}
	public void setDepartureStationId(int beginSationId) {
		this.departureStationId = beginSationId;
	}
	public int getArrivalStationId() {
		return arrivalStationId;
	}
	public void setArrivalStationId(int endStationId) {
		this.arrivalStationId = endStationId;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getTripId() {
		return tripId;
	}
	public void setTripId(int tripId) {
		this.tripId = tripId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getCoachNumber() {
		return coachNumber;
	}
	public void setCoachNumber(int coachNumber) {
		this.coachNumber = coachNumber;
	}
	public int getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}
	public Timestamp getDepartureDate() {
		return new Timestamp(departureDate.getTime());
	}
	public void setDepartureDate(Timestamp departureDate) {
		this.departureDate = new Timestamp(departureDate.getTime());
	}
	public Timestamp getArrivalDate() {
		return new Timestamp(arrivalDate.getTime());
	}
	public void setArrivalDate(Timestamp arrivalDate) {
		this.arrivalDate = new Timestamp(arrivalDate.getTime());
	}
			
}
