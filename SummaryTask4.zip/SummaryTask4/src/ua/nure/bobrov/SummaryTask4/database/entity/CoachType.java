package ua.nure.bobrov.SummaryTask4.database.entity;

/**
 * Class describes a type of coach
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class CoachType extends Entity{

	private static final long serialVersionUID = 6977631162402979463L;
	
	private String name;
	/**
	 * Max passenger number in coach
	 */
	private int maxPassengerNumber;
	/**
	 * File name of picture of the coach
	 */
	private String picture;
	/**
	 * Coefficient of payment
	 */
	private double coefficient;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMaxPassengerNumber() {
		return maxPassengerNumber;
	}
	public void setMaxPassengerNumber(int maxPassengerNumber) {
		this.maxPassengerNumber = maxPassengerNumber;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public double getCoefficient() {
		return coefficient;
	}
	public void setCoefficient(double coefficient) {
		this.coefficient = coefficient;
	}
}
