package ua.nure.bobrov.SummaryTask4.database.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.DBConnector;
import ua.nure.bobrov.SummaryTask4.database.Field;
import ua.nure.bobrov.SummaryTask4.database.entity.CoachType;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;

/**
 * Interacts with database. Operates CoachType data
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class CoachTypeDAO {

	private static final Logger LOG = Logger.getLogger(CoachTypeDAO.class);

	private static final String GET_ALL_COACHTYPES = "SELECT * FROM coachtype";
	private static final String GET_COACHTYPE_BY_PK = "SELECT * FROM coachtype WHERE id_coachtype=?";

	private Connection connection;

	/**
	 * Returns map of coach types as values and ids of coach types as keys
	 * 
	 * @return map of coach types as values and ids of coach types as keys
	 * @throws DatabaseException
	 */
	public Map<Integer, CoachType> getAllInMap() throws DatabaseException {
		Map<Integer, CoachType> coachTypeMap = new TreeMap<Integer, CoachType>();
		CoachType coachType = null;
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(GET_ALL_COACHTYPES);
			while (resultSet.next()) {
				coachType = extract(resultSet);
				coachTypeMap.put(coachType.getId(), coachType);
			}
		} catch (SQLException ex) {
			LOG.error(ex.getMessage(), ex);
			throw new DatabaseException(ex.getMessage(), ex);
		} finally {
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return coachTypeMap;
	}

	/**
	 * Gets coach type from database by its primary key
	 * 
	 * @param pk
	 *            primary key of Coach
	 * @return CoachType object
	 * @throws DatabaseException
	 */
	public CoachType getByPK(int pk) throws DatabaseException {
		PreparedStatement statment = null;
		ResultSet resultSet = null;
		CoachType coach = null;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(GET_COACHTYPE_BY_PK);
			statment.setInt(1, pk);
			resultSet = statment.executeQuery();
			if (resultSet.next()) {
				coach = extract(resultSet);
			}
		} catch (SQLException ex) {
			LOG.error(ex.getMessage(), ex);
			throw new DatabaseException(ex.getMessage(), ex);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return coach;
	}
	/**
	 * Extracts a CoachType object from the result set
	 * 
	 * @param resultSet
	 *            Result set from which a coach type will be extracted.
	 * @return CoachType object
	 * @throws SQLException
	 */
	private CoachType extract(ResultSet resultSet) throws SQLException {
		CoachType coachType = new CoachType();
		coachType.setId(resultSet.getInt(Field.COACHTYPE_ID));
		coachType.setName(resultSet.getString(Field.NAME));
		coachType.setPicture(resultSet.getString(Field.PICTURE));
		coachType.setMaxPassengerNumber(resultSet.getInt(Field.PASSANGER_NUMBER));
		coachType.setCoefficient(resultSet.getDouble(Field.COEFFICIENT));
		return coachType;
	}

}
