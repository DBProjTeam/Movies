package ua.nure.bobrov.SummaryTask4.database.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.DBConnector;
import ua.nure.bobrov.SummaryTask4.database.Field;
import ua.nure.bobrov.SummaryTask4.database.entity.UnconfirmedUser;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;

/**
 * Interacts with database. Operates unconfirmed user data
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class UnconfirmedUserDAO {
	
	private static final Logger LOG = Logger.getLogger(UnconfirmedUserDAO.class);

	private static final String GET_ALL_UNCONFIRMED_USERS = "SELECT * FROM unconfirmed_user";
	private static final String GET_UNCONFIRMED_USER_BY_LOGIN = "SELECT * FROM unconfirmed_user WHERE email=?";
	private static final String GET_UNCONFIRMED_USER_BY_TOKEN = "SELECT * FROM unconfirmed_user WHERE token=?";
	private static final String CREATE_UNCONFIRMED_USER = "INSERT INTO unconfirmed_user(token, email, password, name, surname) VALUES(?,?,?,?,?)";
	
	
	private Connection connection;
	
	/**
	 * Gets UnconfirmedUser List from database
	 * 
	 * @return UnconfirmedUser List
	 * @throws DatabaseException
	 */
	public List<UnconfirmedUser> findAll() throws DatabaseException {
		List<UnconfirmedUser> userList = new ArrayList<UnconfirmedUser>();
		Statement statment = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statment = connection.createStatement();
			resultSet = statment.executeQuery(GET_ALL_UNCONFIRMED_USERS);
			while (resultSet.next()) {
				userList.add(extract(resultSet));
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return userList;
	}
	
	/**
	 * Gets unconfirmed user from database by his email
	 * 
	 * @param email
	 *            email of unconfirmed user
	 * @return UnconfirmedUser object
	 * @throws DatabaseException
	 */
	public UnconfirmedUser getByEmail(String email) throws DatabaseException {
		PreparedStatement statment = null;
		ResultSet resultSet = null;
		UnconfirmedUser user = null;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(GET_UNCONFIRMED_USER_BY_LOGIN);
			statment.setString(1, email);			
			resultSet = statment.executeQuery();
			if (resultSet.next()) {
				user = extract(resultSet);
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return user;
	}
	
	/**
	 * Gets unconfirmed user from database by his token
	 * 
	 * @param token token of the unconfirmed user
	 * @return UnconfirmedUser object
	 * @throws DatabaseException
	 */
	public UnconfirmedUser getByToken(String token) throws DatabaseException {
		PreparedStatement statment = null;
		ResultSet resultSet = null;
		UnconfirmedUser user = null;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(GET_UNCONFIRMED_USER_BY_TOKEN);
			statment.setString(1, token);			
			resultSet = statment.executeQuery();
			if (resultSet.next()) {
				user = extract(resultSet);
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return user;		
	}
	
	/**
	 * Inserts new unconfirmed user in the database
	 * 
	 * @param unconfirmed user
	 *            unconfirmed user to insert
	 * @throws DatabaseException
	 */
	public void insert(UnconfirmedUser user) throws DatabaseException {
		PreparedStatement statement = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(CREATE_UNCONFIRMED_USER);
			statement.setString(1, user.getToken());
			statement.setString(2, user.getEmail());
			statement.setString(3, user.getPassword());			
			statement.setString(4, user.getName());
			statement.setString(5, user.getSurname());				
			statement.executeUpdate();			
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
	}
	
	/**
	 * Extracts a UnconfirmedUser object from the result set
	 * @param resultSet  Result set from which the unconfirmed user will be extracted.
	 * @return UnconfirmedUser object
	 * @throws SQLException
	 */
	private UnconfirmedUser extract(ResultSet resultSet) throws SQLException {
		UnconfirmedUser user = new UnconfirmedUser();
		user.setToken(resultSet.getString(Field.TOKEN));
		user.setEmail(resultSet.getString(Field.EMAIL));
		user.setPassword(resultSet.getString(Field.PASSWORD));		
		user.setName(resultSet.getString(Field.NAME));
		user.setSurname(resultSet.getString(Field.SURNAME));
		return user;		
	}
	
	
}
