package ua.nure.bobrov.SummaryTask4.database.entity;

/**
 * Train entity
 * 
 * @author Bobrov Vyacheslav
 */
public class Train extends Entity{

	private static final long serialVersionUID = 8729169670157704467L;
	
	private String number;

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

}
