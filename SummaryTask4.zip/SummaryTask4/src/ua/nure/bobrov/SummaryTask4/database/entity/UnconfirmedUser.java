package ua.nure.bobrov.SummaryTask4.database.entity;

import java.io.Serializable;

/**
 * Class describes user that has registered but hasn't confirmed registration
 * yet
 * 
 * @author Bobrov Vyacheslav
 *
 */

public class UnconfirmedUser implements Serializable {

	private static final long serialVersionUID = -1825492798857954036L;

	private String token;
	private String email;
	private String password;
	private String name;
	private String surname;

	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}

}
