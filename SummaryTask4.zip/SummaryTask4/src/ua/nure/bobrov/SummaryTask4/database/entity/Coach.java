package ua.nure.bobrov.SummaryTask4.database.entity;

import ua.nure.bobrov.SummaryTask4.database.entity.CoachType;

/**
 * Coach entity
 * 
 * @author Bobrov Vyacheslav
 */
public class Coach extends Entity{

	private static final long serialVersionUID = -3522164115155915885L;
	
	private int trainId;
	private int number;
	private CoachType type;
			
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public CoachType getType() {
		return type;
	}
	public void setType(CoachType type) {
		this.type = type;
	}
	public int getTrainId() {
		return trainId;
	}
	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}
	
}
