package ua.nure.bobrov.SummaryTask4.database.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.DBConnector;
import ua.nure.bobrov.SummaryTask4.database.Field;
import ua.nure.bobrov.SummaryTask4.database.entity.User;
import ua.nure.bobrov.SummaryTask4.enums.RoleType;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;

/**
 * Interacts with database. Operates user data
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class UserDAO {

	private static final Logger LOG = Logger.getLogger(UserDAO.class);

	private static final String GET_ALL_CLIENTS_AND_MANAGERS = "SELECT * FROM user WHERE id_role!=0";
	private static final String GET_USER_BY_PK = "SELECT * FROM user WHERE id_user=?";
	private static final String GET_USER_BY_EMAIL = "SELECT * FROM user WHERE email=?";
	private static final String CREATE_USER = "INSERT INTO user(email, password, name, surname, id_role, banned) VALUES(?,?,?,?,?,?)";
	private static final String UPDATE_USER = "UPDATE user SET email=?, password=?, name=?, surname=?, id_role=?,  banned=? WHERE id_user=?";
	private static final String UPDATE_BANNED_USER = "UPDATE user SET banned=? WHERE id_user=?";
	private static final String DELETE_USER = "DELETE FROM user WHERE id_user=?";
	private static final String DELETE_UNCONFIRMED_USER = "DELETE FROM unconfirmed_user WHERE email=?";

	private Connection connection;

	/**
	 * GetsUser List from database
	 * 
	 * @return User List
	 * @throws DatabaseException
	 */
	public List<User> findAll() throws DatabaseException {
		List<User> userList = new ArrayList<User>();
		Statement statment = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statment = connection.createStatement();
			resultSet = statment.executeQuery(GET_ALL_CLIENTS_AND_MANAGERS);
			while (resultSet.next()) {
				userList.add(extract(resultSet));
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return userList;
	}

	/**
	 * Gets user from database by his id
	 * 
	 * @param id
	 *            id of the user
	 * @return User object
	 * @throws DatabaseException
	 */
	public User getByPK(int pk) throws DatabaseException {
		PreparedStatement statment = null;
		ResultSet resultSet = null;
		User user = null;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(GET_USER_BY_PK);
			statment.setInt(1, pk);
			resultSet = statment.executeQuery();
			if (resultSet.next()) {
				user = extract(resultSet);
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return user;
	}

	/**
	 * Gets user from database by his email
	 * 
	 * @param email
	 *            email of the user
	 * @return User object
	 * @throws DatabaseException
	 */
	public User getByEmail(String email) throws DatabaseException {
		PreparedStatement statment = null;
		ResultSet resultSet = null;
		User user = null;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(GET_USER_BY_EMAIL);
			statment.setString(1, email);
			resultSet = statment.executeQuery();
			if (resultSet.next()) {
				user = extract(resultSet);
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return user;
	}

	/**
	 * Inserts new user in the database and deletes unconfirmed user with the
	 * same email
	 * 
	 * @param user
	 *            user to insert
	 * @throws DatabaseException
	 */
	public void insert(User user) throws DatabaseException {
		PreparedStatement statement = null;
		try {
			connection = DBConnector.getConnection();
			connection.setAutoCommit(false);
			connection.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
			deleteUnconfirmedUser(connection, user.getEmail());

			statement = connection.prepareStatement(CREATE_USER);
			statement.setString(1, user.getEmail());
			statement.setString(2, user.getPassword());
			statement.setString(3, user.getName());
			statement.setString(4, user.getSurname());
			statement.setInt(5, user.getRole().ordinal());
			statement.setBoolean(6, user.isBanned());
			statement.executeUpdate();
			connection.commit();
		} catch (SQLException e) {
			DBConnector.rollback(connection);
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
	}

	/**
	 * Inserts user in the database
	 * 
	 * @param user
	 *            user to update
	 * @return true if user was updated, false otherwise
	 * @throws DatabaseException
	 */
	public boolean update(User user) throws DatabaseException {
		PreparedStatement statement = null;
		boolean isUpdated = false;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(UPDATE_USER);
			statement.setString(1, user.getEmail());
			statement.setString(2, user.getPassword());
			statement.setString(3, user.getName());
			statement.setString(4, user.getSurname());
			statement.setInt(5, user.getRole().ordinal());
			statement.setBoolean(6, user.isBanned());
			statement.setInt(7, user.getId());
			if (statement.executeUpdate() != 0) {
				isUpdated = true;
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return isUpdated;
	}
	/**
	 * Updates user banned status
	 * 
	 * @param userId
	 *            id of the user
	 * @param isBanned
	 *            status
	 * @return true if user was updated, false otherwise
	 * @throws DatabaseException
	 */
	public boolean updateBanned(int userId, boolean isBanned) throws DatabaseException {
		PreparedStatement statement = null;
		boolean isUpdated = false;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(UPDATE_BANNED_USER);
			statement.setInt(1, userId);
			statement.setBoolean(2, isBanned);
			if (statement.executeUpdate() != 0) {
				isUpdated = true;
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return isUpdated;
	}

	/**
	 * Deletes user from database
	 * 
	 * @param pk
	 *            primary key of the user to delete
	 * @return true if user was deleted, false otherwise
	 * @throws DatabaseException
	 */
	public boolean delete(int pk) throws DatabaseException {
		PreparedStatement statment = null;
		boolean isDeleted = false;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(DELETE_USER);
			statment.setInt(1, pk);
			if (statment.executeUpdate() != 0) {
				isDeleted = true;
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeConnection(connection);
		}
		return isDeleted;
	}

	/**
	 * Deletes unconfirmed user
	 * 
	 * @param connection
	 * @param email
	 * @throws DatabaseException
	 */
	private void deleteUnconfirmedUser(Connection connection, String email) throws DatabaseException {
		PreparedStatement statment = null;
		try {
			statment = connection.prepareStatement(DELETE_UNCONFIRMED_USER);
			statment.setString(1, email);
			statment.executeUpdate();
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
		}
	}
	/**
	 * Extracts a User object from the result set
	 * 
	 * @param resultSet
	 *            Result set from which theuser will be extracted.
	 * @return User object
	 * @throws SQLException
	 */
	private User extract(ResultSet resultSet) throws SQLException {
		User user = new User();
		user.setId(resultSet.getInt(Field.USER_ID));
		user.setEmail(resultSet.getString(Field.EMAIL));
		user.setPassword(resultSet.getString(Field.PASSWORD));
		user.setName(resultSet.getString(Field.NAME));
		user.setSurname(resultSet.getString(Field.SURNAME));
		user.setRole(RoleType.getRoleType(resultSet.getInt(Field.ROLE_ID)));
		user.setBanned(resultSet.getBoolean(Field.BANNED));
		return user;
	}
}
