package ua.nure.bobrov.SummaryTask4.database.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.DBConnector;
import ua.nure.bobrov.SummaryTask4.database.Field;
import ua.nure.bobrov.SummaryTask4.database.entity.Ticket;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;

/**
 * Interacts with database. Operates ticket data
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class TicketDAO {

	private static final Logger LOG = Logger.getLogger(TicketDAO.class);
	
	private static final String GET_ALL_TICKETS_BY_TRIP_ID = "SELECT * FROM ticket WHERE id_trip=?";

	private static final String GET_ALL_TICKETS = "SELECT * FROM ticket";
	private static final String GET_ALL_TICKETS_BY_USER_ID = "SELECT * FROM ticket WHERE id_user=?";
	private static final String GET_ALL_TICKETS_BY_DATE_RANGE = "SELECT * FROM ticket WHERE id_trip=? AND NOT (?<=departure_date OR ?>=arrival_date)";
	private static final String CREATE_TICKET = "INSERT INTO ticket(id_trip, id_user, id_begin_station, id_end_station, id_coachtype, coach_number, seat_number, price, departure_date, arrival_date) VALUES(?,?,?,?,?,?,?,?,?,?)";
	private static final String DELETE_TICKET = "DELETE FROM ticket WHERE id_ticket=?";
	private static final String GET_TICKET_BY_PK = "SELECT * FROM ticket WHERE id_ticket=?";

	private Connection connection;

	
	public List<Ticket> findAllByTriId(int tripId)
			throws DatabaseException {
		List<Ticket> ticketList = new ArrayList<Ticket>();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(GET_ALL_TICKETS_BY_TRIP_ID);
			statement.setInt(1, tripId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				ticketList.add(extract(resultSet));
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return ticketList;
	}
	
	
	
	/**
	 * Gets Ticket List from database
	 * 
	 * @return Ticket List
	 * @throws DatabaseException
	 */
	public List<Ticket> findAll() throws DatabaseException {
		List<Ticket> ticketList = new ArrayList<Ticket>();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(GET_ALL_TICKETS);
			while (resultSet.next()) {
				ticketList.add(extract(resultSet));
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return ticketList;
	}

	/**
	 * Gets Ticket List from database by date range
	 * 
	 * @param tripId
	 * @param departureDate
	 * @param arrivalDate
	 * @return Ticket List
	 * @throws DatabaseException
	 */
	public List<Ticket> findAllByDateRange(int tripId, Timestamp departureDate, Timestamp arrivalDate)
			throws DatabaseException {
		List<Ticket> ticketList = new ArrayList<Ticket>();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(GET_ALL_TICKETS_BY_DATE_RANGE);
			statement.setInt(1, tripId);
			statement.setTimestamp(2, arrivalDate);
			statement.setTimestamp(3, departureDate);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				ticketList.add(extract(resultSet));
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return ticketList;
	}

	/**
	 * Gets Ticket List from database by user id
	 * 
	 * @param userId
	 *            id of the user
	 * @return Ticket List
	 * @throws DatabaseException
	 */
	public List<Ticket> findAllByUserId(int userId) throws DatabaseException {
		List<Ticket> ticketList = new ArrayList<Ticket>();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(GET_ALL_TICKETS_BY_USER_ID);
			statement.setInt(1, userId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				ticketList.add(extract(resultSet));
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return ticketList;
	}

	/**
	 * Inserts new ticket in the database
	 * 
	 * @param ticket
	 *            ticket to insert
	 * @throws DatabaseException
	 */
	public void insert(Ticket ticket) throws DatabaseException {
		PreparedStatement statement = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(CREATE_TICKET);
			statement.setInt(1, ticket.getTripId());
			statement.setInt(2, ticket.getUserId());
			statement.setInt(3, ticket.getDepartureStationId());
			statement.setInt(4, ticket.getArrivalStationId());
			statement.setInt(5, ticket.getCoachTypeId());
			statement.setInt(6, ticket.getCoachNumber());
			statement.setInt(7, ticket.getSeatNumber());
			statement.setDouble(8, ticket.getPrice());
			statement.setTimestamp(9, ticket.getDepartureDate());
			statement.setTimestamp(10, ticket.getArrivalDate());
			statement.executeUpdate();
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
	}

	/**
	 * Deletes ticket from the database
	 * 
	 * @param pk
	 *            primary key of the ticket
	 * @return true if ticket was deleted, false otherwise
	 * @throws DatabaseException
	 */
	public boolean delete(int pk) throws DatabaseException {
		PreparedStatement statement = null;
		boolean isDeleted = false;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(DELETE_TICKET);
			statement.setInt(1, pk);
			if (statement.executeUpdate() != 0) {
				isDeleted = true;
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return isDeleted;
	}

	/**
	 * Gets ticket from database by its primary key
	 * 
	 * @param pk
	 *            primary key of ticket
	 * @return Ticket object
	 * @throws DatabaseException
	 */
	public Ticket getByPK(int pk) throws DatabaseException {
		PreparedStatement statment = null;
		ResultSet resultSet = null;
		Ticket ticket = null;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(GET_TICKET_BY_PK);
			statment.setInt(1, pk);
			resultSet = statment.executeQuery();
			if (resultSet.next()) {
				ticket = extract(resultSet);
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return ticket;
	}
	
	/**
	 * Extracts a Ticket object from the result set
	 * @param resultSet  Result set from which the ticket will be extracted.
	 * @return Ticket object
	 * @throws SQLException
	 */
	private Ticket extract(ResultSet resultSet) throws SQLException {
		Ticket ticket = new Ticket();
		ticket.setId(resultSet.getInt(Field.TICKET_ID));
		ticket.setTripId(resultSet.getInt(Field.TRIP_ID));
		ticket.setUserId(resultSet.getInt(Field.USER_ID));
		ticket.setDepartureStationId(resultSet.getInt(Field.BEGIN_STATION_ID));
		ticket.setArrivalStationId(resultSet.getInt(Field.END_STATION_ID));
		ticket.setCoachTypeId(resultSet.getInt(Field.COACHTYPE_ID));
		ticket.setCoachNumber(resultSet.getInt(Field.COACH_NUMBER));
		ticket.setSeatNumber(resultSet.getInt(Field.SEAT_NUMBER));
		ticket.setPrice(resultSet.getDouble(Field.PRICE));
		ticket.setDepartureDate(resultSet.getTimestamp(Field.DEPARTURE_DATE));
		ticket.setArrivalDate(resultSet.getTimestamp(Field.ARRIVAL_DATE));
		return ticket;
	}

}
