package ua.nure.bobrov.SummaryTask4.database.entity;

import ua.nure.bobrov.SummaryTask4.enums.RoleType;

/**
 * User entity
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class User extends Entity {

	private static final long serialVersionUID = 7403493202256390038L;

	private String email;
	private String password;	
	private String name;
	private String surname;
	private RoleType role;
	private boolean isBanned;
		
	public RoleType getRole() {
		return role;
	}
	public void setRole(RoleType role) {
		this.role = role;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public boolean isBanned() {
		return isBanned;
	}
	public void setBanned(boolean isBanned) {
		this.isBanned = isBanned;
	}
	
}
