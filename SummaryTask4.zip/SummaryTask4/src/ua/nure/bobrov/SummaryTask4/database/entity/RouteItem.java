package ua.nure.bobrov.SummaryTask4.database.entity;

import java.sql.Time;

/**
 * Route item entity
 * 
 * @author Bobrov Vyacheslav
 */
public class RouteItem extends Entity {

	private static final long serialVersionUID = -369190145202962373L;

	private int routeId;
	private int stationId;	
	private Time arrivalTime;	
	private Time departureTime;	
	/**
	 * Sequence number in route
	 */
	private int sequenceNumber;
	
	public RouteItem() {		
	}
	
	public RouteItem(int routeId, int stationId, Time arrivalTime, Time departureTime, int sequenceNumber) {
		this.routeId = routeId;
		this.stationId = stationId;
		this.arrivalTime = arrivalTime;
		this.departureTime = departureTime;
		this.sequenceNumber = sequenceNumber;
	}

	public int getRouteId() {
		return routeId;
	}

	public void setRouteId(int routeId) {
		this.routeId = routeId;
	}
	
	public int getStationId() {
		return stationId;
	}

	public void setStationId(int stationId) {
		this.stationId = stationId;
	}

	public int getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(int sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public Time getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(Time arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public Time getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(Time departureTime) {
		this.departureTime = departureTime;
	}	

}
