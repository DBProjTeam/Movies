package ua.nure.bobrov.SummaryTask4.database.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.DBConnector;
import ua.nure.bobrov.SummaryTask4.database.Field;
import ua.nure.bobrov.SummaryTask4.database.entity.Station;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;

/**
 * Interacts with database. Operates station data
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class StationDAO {

	private static final Logger LOG = Logger.getLogger(StationDAO.class);
	
	private static final String GET_ALL_STATIONS = "SELECT * FROM station";
	private static final String CREATE_STATION = "INSERT INTO station(name) VALUES(?)";
	private static final String UPDATE_STATION = "UPDATE station SET name=? WHERE id_station=?";
	private static final String DELETE_STATION = "DELETE FROM station WHERE id_station=?";
	private static final String GET_STATION_BY_PK = "SELECT * FROM station WHERE id_station=?";

	private static final String GET_STATION_BY_NAME = "SELECT * FROM station WHERE name=?";

	private Connection connection;

	/**
	 * Gets Station List from database
	 * 
	 * @return Station List
	 * @throws DatabaseException
	 */
	public List<Station> findAll() throws DatabaseException {
		List<Station> stationList = new ArrayList<Station>();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(GET_ALL_STATIONS);
			while (resultSet.next()) {
				stationList.add(extract(resultSet));
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return stationList;
	}
	
	/**
	 * Inserts new station in the database
	 * 
	 * @param station
	 *            station to insert
	 * @throws DatabaseException
	 */
	public void insert(Station station) throws DatabaseException {
		PreparedStatement statement = null;		
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(CREATE_STATION);
			statement.setString(1, station.getName());
			statement.executeUpdate();
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}		
	}

	/**
	 * Updates station in the database
	 * 
	 * @param station
	 *            station to update
	 * @return true if station  was updated, false otherwise
	 * @throws DatabaseException
	 */
	public boolean update(Station station) throws DatabaseException {
		PreparedStatement statment = null;
		boolean isUpdated = false;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(UPDATE_STATION);
			statment.setString(1, station.getName());
			statment.setInt(2, station.getId());
			if(statment.executeUpdate() != 0) {
				isUpdated = true;
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeConnection(connection);
		}
		return isUpdated;
	}
	
	/**
	 * Deletes station from the database
	 * 
	 * @param pk
	 *            primary key of the station
	 * @return true if station was deleted, false otherwise
	 * @throws DatabaseException
	 */
	public boolean delete(int pk) throws DatabaseException {
		PreparedStatement statment = null;
		boolean isDeleted = false;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(DELETE_STATION);
			statment.setInt(1, pk);
			if(statment.executeUpdate() != 0) {
				isDeleted = true;
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeConnection(connection);
		}
		return isDeleted;
	}
	
	/**
	 * Gets station from database by its primary key
	 * 
	 * @param pk
	 *            primary key of station
	 * @return Station object
	 * @throws DatabaseException
	 */
	public Station getByPK(int pk) throws DatabaseException {
		PreparedStatement statment = null;
		ResultSet resultSet = null;
		Station station = null;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(GET_STATION_BY_PK);
			statment.setInt(1, pk);
			resultSet = statment.executeQuery();
			if (resultSet.next()) {
				station = extract(resultSet);
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return station;
	}

	/**
	 * Gets station from database by its name
	 * 
	 * @param name
	 *            name of station
	 * @return Station object
	 * @throws DatabaseException
	 */
	public Station getByName(String name) throws DatabaseException {
		PreparedStatement statment = null;
		ResultSet resultSet = null;
		Station station = null;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(GET_STATION_BY_NAME);
			statment.setString(1, name);
			resultSet = statment.executeQuery();
			if (resultSet.next()) {
				station = extract(resultSet);
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return station;
	}
	
	/**
	 * Extracts a Station object from the result set
	 * @param resultSet  Result set from which the station will be extracted.
	 * @return Station object
	 * @throws SQLException
	 */
	private Station extract(ResultSet resultSet) throws SQLException {
		Station station = new Station();
		station.setId(resultSet.getInt(Field.STATION_ID));
		station.setName(resultSet.getString(Field.NAME));
		return station;
	}

}
