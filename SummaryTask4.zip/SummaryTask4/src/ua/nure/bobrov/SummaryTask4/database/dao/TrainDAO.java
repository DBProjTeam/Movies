package ua.nure.bobrov.SummaryTask4.database.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.DBConnector;
import ua.nure.bobrov.SummaryTask4.database.Field;
import ua.nure.bobrov.SummaryTask4.database.entity.Train;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;

/**
 * Interacts with database. Operates train data
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class TrainDAO {
	
	private static final Logger LOG = Logger.getLogger(TrainDAO.class);
	
	private static final String GET_ALL_TRAINS = "SELECT * FROM train";
	private static final String GET_TRAIN_BY_PK = "SELECT * FROM train WHERE id_train=?";

	private Connection connection;

	/**
	 * Gets Train List from database
	 * 
	 * @return Train List
	 * @throws DatabaseException
	 */
	public List<Train> findAll() throws DatabaseException {
		List<Train> trainList = new ArrayList<Train>();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(GET_ALL_TRAINS);
			while (resultSet.next()) {
				trainList.add(extract(resultSet));
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return trainList;
	}

	/**
	 * Gets train from database by its primary key
	 * 
	 * @param pk
	 *            primary key of train
	 * @return Train object
	 * @throws DatabaseException
	 */
	public Train getByPK(int pk) throws DatabaseException {
		PreparedStatement statment = null;
		ResultSet resultSet = null;
		Train train = null;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(GET_TRAIN_BY_PK);
			statment.setInt(1, pk);
			resultSet = statment.executeQuery();
			if (resultSet.next()) {
				train = extract(resultSet);
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return train;
	}
	/**
	 * Extracts a Train object from the result set
	 * @param resultSet  Result set from which the train will be extracted.
	 * @return Train object
	 * @throws SQLException
	 */
	private Train extract(ResultSet resultSet) throws SQLException {
		Train train = new Train();
		train.setId(resultSet.getInt(Field.TRAIN_ID));
		train.setNumber(resultSet.getString(Field.NUMBER));			
		return train;
	}
}
