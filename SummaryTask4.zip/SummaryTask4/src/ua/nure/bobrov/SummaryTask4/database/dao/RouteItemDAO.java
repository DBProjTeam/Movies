package ua.nure.bobrov.SummaryTask4.database.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.DBConnector;
import ua.nure.bobrov.SummaryTask4.database.Field;
import ua.nure.bobrov.SummaryTask4.database.entity.RouteItem;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;

/**
 * Interacts with database. Operates route item data
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class RouteItemDAO {

	private static final Logger LOG = Logger.getLogger(RouteItemDAO.class);

	private static final String GET_ALL_ROUTEITEMS = "SELECT * FROM routeitem ORDER BY id_route, sequence_number";
	private static final String GET_ALL_ROUTEITEMS_BY_ROUTE_ID = "SELECT * FROM routeitem WHERE id_route=? ORDER BY sequence_number";
	private static final String CREATE_ROUTEITEM = "INSERT INTO routeitem(id_route, id_station, arrival_time, departure_time, sequence_number) VALUES(?,?,?,?,?)";
	private static final String UPDATE_ROUTEITEM = "UPDATE routeitem SET id_route=?, id_station=?, arrival_time=?, departure_time=?, sequence_number=? WHERE id_routeitem=?";
	private static final String DELETE_ROUTEITEM = "DELETE FROM routeitem WHERE id_routeitem=?";
	private static final String GET_ROUTEITEM_BY_PK = "SELECT * FROM routeitem WHERE id_routeitem=?";

	private static final String GET_ROUTEITEM_BY_ROUTE_AND_STATION_IDS = "SELECT * FROM routeitem WHERE id_routeitem!=? AND id_route=? AND (id_station=? OR sequence_number=?) ";

	private Connection connection;

	/**
	 * Gets RouteItem List from database
	 * 
	 * @return RouteItem List
	 * @throws DatabaseException
	 */
	public List<RouteItem> findAll() throws DatabaseException {
		List<RouteItem> routeItemList = new ArrayList<RouteItem>();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(GET_ALL_ROUTEITEMS);
			while (resultSet.next()) {
				routeItemList.add(extract(resultSet));
			}
		} catch (SQLException ex) {
			LOG.error(ex.getMessage(), ex);
			throw new DatabaseException(ex.getMessage(), ex);
		} finally {
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return routeItemList;
	}

	/**
	 * Gets RouteItem List from database by route id
	 * 
	 * @param id
	 *            id of the route
	 * @return RouteItem List
	 * @throws DatabaseException
	 */
	public List<RouteItem> findAllByRouteId(int id) throws DatabaseException {
		List<RouteItem> routeItemList = new ArrayList<RouteItem>();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(GET_ALL_ROUTEITEMS_BY_ROUTE_ID);
			statement.setInt(1, id);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				routeItemList.add(extract(resultSet));
			}
		} catch (SQLException ex) {
			LOG.error(ex.getMessage(), ex);
			throw new DatabaseException(ex.getMessage(), ex);
		} finally {
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return routeItemList;
	}

	/**
	 * Inserts new route item in the database
	 * 
	 * @param routeItem
	 *            route item to insert
	 * @throws DatabaseException
	 */
	public void insert(RouteItem routeItem) throws DatabaseException {
		PreparedStatement statement = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(CREATE_ROUTEITEM);
			statement.setInt(1, routeItem.getRouteId());
			statement.setInt(2, routeItem.getStationId());
			statement.setTime(3, routeItem.getArrivalTime());
			statement.setTime(4, routeItem.getDepartureTime());
			statement.setInt(5, routeItem.getSequenceNumber());

			statement.executeUpdate();
		} catch (SQLException ex) {
			LOG.error(ex.getMessage(), ex);
			throw new DatabaseException(ex.getMessage(), ex);
		} finally {
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
	}

	/**
	 * Updates route item in the database
	 * 
	 * @param routeItem
	 *            route item to update
	 * @return true if route item was updated, false otherwise
	 * @throws DatabaseException
	 */
	public boolean update(RouteItem routeItem) throws DatabaseException {
		PreparedStatement statement = null;
		boolean isUpdated = false;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(UPDATE_ROUTEITEM);
			statement.setInt(1, routeItem.getRouteId());
			statement.setInt(2, routeItem.getStationId());
			statement.setTime(3, routeItem.getArrivalTime());
			statement.setTime(4, routeItem.getDepartureTime());
			statement.setInt(5, routeItem.getSequenceNumber());
			statement.setInt(6, routeItem.getId());
			if(statement.executeUpdate() != 0) {
				isUpdated = true;
			}
		} catch (SQLException ex) {
			LOG.error(ex.getMessage(), ex);
			throw new DatabaseException(ex.getMessage(), ex);
		} finally {
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return isUpdated;
	}

	/**
	 * Deletes route item from the database
	 * 
	 * @param pk
	 *            primary key of the route item
	 * @return true if route item was deleted, false otherwise
	 * @throws DatabaseException
	 */
	public boolean delete(int pk) throws DatabaseException {
		PreparedStatement statment = null;
		boolean isDeleted = false;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(DELETE_ROUTEITEM);
			statment.setInt(1, pk);
			if (statment.executeUpdate() != 0) {
				isDeleted = true;
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeConnection(connection);
		}
		return isDeleted;
	}

	/**
	 * Gets route item from database by its primary key
	 * 
	 * @param pk
	 *            primary key of route item
	 * @return RouteItem object
	 * @throws DatabaseException
	 */
	public RouteItem getByPK(int pk) throws DatabaseException {
		PreparedStatement statment = null;
		ResultSet resultSet = null;
		RouteItem routeItem = null;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(GET_ROUTEITEM_BY_PK);
			statment.setInt(1, pk);
			resultSet = statment.executeQuery();
			if (resultSet.next()) {
				routeItem = extract(resultSet);
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return routeItem;
	}

	/**
	 * Checks if route item is already in database
	 * 
	 * @param routeItem
	 *            route item to check
	 * @return true if route item is already in database, false otherwise
	 * @throws DatabaseException
	 */
	public boolean exists(RouteItem routeItem) throws DatabaseException {
		PreparedStatement statment = null;
		ResultSet resultSet = null;
		boolean isExist = false;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(GET_ROUTEITEM_BY_ROUTE_AND_STATION_IDS);
			statment.setInt(1, routeItem.getId());
			statment.setInt(2, routeItem.getRouteId());
			statment.setInt(3, routeItem.getStationId());
			statment.setInt(4, routeItem.getSequenceNumber());
			resultSet = statment.executeQuery();
			if (resultSet.next()) {
				isExist = true;
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return isExist;
	}

	/**
	 * Extracts a RouteItem object from the result set
	 * 
	 * @param resultSet
	 *            Result set from which the route item will be extracted.
	 * @return RouteItem object
	 * @throws SQLException
	 */
	private RouteItem extract(ResultSet resultSet) throws SQLException {
		RouteItem routeItem = new RouteItem();
		routeItem.setId(resultSet.getInt(Field.ROUTEITEM_ID));
		routeItem.setRouteId(resultSet.getInt(Field.ROUTE_ID));
		routeItem.setStationId(resultSet.getInt(Field.STATION_ID));
		routeItem.setArrivalTime(resultSet.getTime(Field.ARRIVAL_TIME));
		routeItem.setDepartureTime(resultSet.getTime(Field.DEPARTURE_TIME));
		routeItem.setSequenceNumber(resultSet.getInt(Field.SEQUENCE_NUMBER));

		return routeItem;
	}
}
