package ua.nure.bobrov.SummaryTask4.database.entity;

import java.sql.Time;

/**
 * Route entity
 * 
 * @author Bobrov Vyacheslav
 */
public class Route extends Entity {

	private static final long serialVersionUID = -6842592168687186770L;

	private Station beginStation;
	private Station endStation;
	private Time beginTime;
	private Time endTime;
	
	public Station getBeginStation() {
		return beginStation;
	}

	public void setBeginStation(Station beginStation) {
		this.beginStation = beginStation;
	}

	public Station getEndStation() {
		return endStation;
	}

	public void setEndStation(Station endStation) {
		this.endStation = endStation;
	}

	public Time getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(Time beginTime) {
		this.beginTime = beginTime;
	}

	public Time getEndTime() {
		return endTime;
	}

	public void setEndTime(Time endTime) {
		this.endTime = endTime;
	}
	
}
