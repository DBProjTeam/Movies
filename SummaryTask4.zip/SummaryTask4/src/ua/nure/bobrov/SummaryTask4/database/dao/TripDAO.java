package ua.nure.bobrov.SummaryTask4.database.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.DBConnector;
import ua.nure.bobrov.SummaryTask4.database.Field;
import ua.nure.bobrov.SummaryTask4.database.entity.Trip;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;

/**
 * Interacts with database. Operates trip data
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class TripDAO {

	private static final Logger LOG = Logger.getLogger(TripDAO.class);
	
	private static final String GET_ALL_TRIPS_BY_ROUTE_ID = "SELECT * FROM trip WHERE id_route=?";
	
	private static final String GET_ALL_TRIPS = "SELECT * FROM trip";
	private static final String GET_ALL_TRIPS_BY_DEPARTURE_DATE = "SELECT * FROM trip WHERE ?>=DATE(departure_date)";
	private static final String CREATE_TRIP = "INSERT INTO trip(id_train, id_route, departure_date) VALUES(?,?,?)";
	private static final String UPDATE_TRIP = "UPDATE trip SET id_train=?, id_route=?, departure_date=? WHERE id_trip=?";
	private static final String DELETE_TRIP = "DELETE FROM trip WHERE id_trip=?";
	private static final String GET_TRIP_BY_PK = "SELECT * FROM trip WHERE id_trip=?";

	private static final String GET_TRIP_BY_ATTRIBUTES = "SELECT * FROM trip WHERE id_route=? AND id_train=? AND departure_date=?";

	private Connection connection;

	public List<Trip> findAllByRouteId(int routeId) throws DatabaseException {
		List<Trip> tripList = new ArrayList<Trip>();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(GET_ALL_TRIPS_BY_ROUTE_ID);
			statement.setInt(1, routeId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				tripList.add(extract(resultSet));
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return tripList;
	}
	
	
	/**
	 * Gets Trip List from database
	 * 
	 * @return Trip List
	 * @throws DatabaseException
	 */
	public List<Trip> findAll() throws DatabaseException {
		List<Trip> tripList = new ArrayList<Trip>();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(GET_ALL_TRIPS);
			while (resultSet.next()) {
				tripList.add(extract(resultSet));
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return tripList;
	}

	/**
	 * Gets Trip List from database
	 * @param departureDate
	 * @return Trip List
	 * @throws DatabaseException
	 */
	public List<Trip> findAllByDepartureDate(Date departureDate) throws DatabaseException {
		List<Trip> tripList = new ArrayList<Trip>();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(GET_ALL_TRIPS_BY_DEPARTURE_DATE);
			statement.setDate(1, departureDate);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				tripList.add(extract(resultSet));
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return tripList;
	}

	/**
	 * Inserts new trip in the database
	 * 
	 * @param trip
	 *            trip to insert
	 * @throws DatabaseException
	 */
	public void insert(Trip trip) throws DatabaseException {
		PreparedStatement statement = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(CREATE_TRIP);
			statement.setInt(1, trip.getTrainId());
			statement.setInt(2, trip.getRouteId());
			statement.setDate(3, trip.getDepartureDate());
			statement.executeUpdate();
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
	}

	/**
	 * Updates trip in the database
	 * 
	 * @param trip
	 *            trip to update
	 * @return true if trip  was updated, false otherwise
	 * @throws DatabaseException
	 */
	public boolean update(Trip trip) throws DatabaseException {
		PreparedStatement statement = null;
		boolean isUpdated = false;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(UPDATE_TRIP);
			statement.setInt(1, trip.getTrainId());
			statement.setInt(2, trip.getRouteId());
			statement.setDate(3, trip.getDepartureDate());
			statement.setInt(4, trip.getId());
			if(statement.executeUpdate() != 0) {
				isUpdated = true;
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return isUpdated;
	}
	
	/**
	 * Deletes trip from the database
	 * 
	 * @param pk
	 *            primary key of the trip
	 * @return true if trip was deleted, false otherwise
	 * @throws DatabaseException
	 */
	public boolean delete(int pk) throws DatabaseException {
		PreparedStatement statment = null;
		boolean isDeleted = false;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(DELETE_TRIP);
			statment.setInt(1, pk);
			if (statment.executeUpdate() != 0) {
				isDeleted = true;
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeConnection(connection);
		}
		return isDeleted;
	}

	/**
	 * Gets trip from database by its primary key
	 * 
	 * @param pk
	 *            primary key of trip
	 * @return Trip object
	 * @throws DatabaseException
	 */
	public Trip getByPK(int pk) throws DatabaseException {
		PreparedStatement statment = null;
		ResultSet resultSet = null;
		Trip trip = null;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(GET_TRIP_BY_PK);
			statment.setInt(1, pk);
			resultSet = statment.executeQuery();
			if (resultSet.next()) {
				trip = extract(resultSet);
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return trip;
	}
	
	/**
	 * Checks if trip is already in database
	 * 
	 * @param trip
	 *            trip to check
	 * @return true if trip is already in database, false otherwise
	 * @throws DatabaseException
	 */
	public boolean exists(Trip trip) throws DatabaseException {
		PreparedStatement statment = null;
		ResultSet resultSet = null;
		boolean isExist = false;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(GET_TRIP_BY_ATTRIBUTES);
			statment.setInt(1, trip.getRouteId());
			statment.setInt(2, trip.getTrainId());
			statment.setDate(3, trip.getDepartureDate());
			resultSet = statment.executeQuery();
			if (resultSet.next()) {
				isExist = true;
			}
		} catch (SQLException e) {
			LOG.error(e.getMessage(), e);
			throw new DatabaseException(e.getMessage(), e);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return isExist;
	}
	/**
	 * Extracts a Trip object from the result set
	 * @param resultSet  Result set from which the trip will be extracted.
	 * @return Trip object
	 * @throws SQLException
	 */
	private Trip extract(ResultSet resultSet) throws SQLException {
		Trip trip = new Trip();
		trip.setId(resultSet.getInt(Field.TRIP_ID));
		trip.setTrainId(resultSet.getInt(Field.TRAIN_ID));
		trip.setRouteId(resultSet.getInt(Field.ROUTE_ID));
		trip.setDepartureDate(resultSet.getDate(Field.DEPARTURE_DATE));
		return trip;
	}
}
