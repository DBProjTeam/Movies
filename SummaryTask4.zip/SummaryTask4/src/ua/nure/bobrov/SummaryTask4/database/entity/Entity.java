package ua.nure.bobrov.SummaryTask4.database.entity;

import java.io.Serializable;

/**
 * Class describes an abstract Entity in database
 * 
 * @author Bobrov Vyacheslav
 */
public abstract class Entity implements Serializable{

	private static final long serialVersionUID = -49054550924103012L;
	
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
}
