package ua.nure.bobrov.SummaryTask4.database.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.DBConnector;
import ua.nure.bobrov.SummaryTask4.database.Field;
import ua.nure.bobrov.SummaryTask4.database.entity.Coach;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
/**
 * Interacts with database. Operates Coach data
 * 
 * @author Bobrov Vyacheslav
 */
public class CoachDAO {

	private static final Logger LOG = Logger.getLogger(CoachDAO.class);
	
	private static final String GET_ALL_COACHES = "SELECT * FROM coach";
	private static final String GET_ALL_COACHES_BY_TRAIN_ID = "SELECT * FROM coach WHERE id_train=?";
	private static final String GET_COACH_BY_PK = "SELECT * FROM coach WHERE id_coach=?";	
		
	private Connection connection;
	
	/**
	 * Gets Coach List from database 
	 * @return Coach List
	 * @throws DatabaseException
	 */
	public List<Coach> findAll() throws DatabaseException {
		List<Coach> coachList = new ArrayList<Coach>();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.createStatement();			
			resultSet = statement.executeQuery(GET_ALL_COACHES);
			while (resultSet.next()) {
				coachList.add(extract(resultSet));
			}
		} catch (SQLException ex) {
			LOG.error(ex.getMessage(), ex);
			throw new DatabaseException(ex.getMessage(), ex);
		} finally {
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return coachList;
	}
	
	/**
	 * Gets Coach List by train id from database 
	 * @param id of a Train
	 * @return Coach List
	 * @throws DatabaseException
	 */
	public List<Coach> findAllByTrainId(int id) throws DatabaseException {
		List<Coach> coachList = new ArrayList<Coach>();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = DBConnector.getConnection();
			statement = connection.prepareStatement(GET_ALL_COACHES_BY_TRAIN_ID);
			statement.setInt(1, id);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				coachList.add(extract(resultSet));
			}
		} catch (SQLException ex) {
			LOG.error(ex.getMessage(), ex);
			throw new DatabaseException(ex.getMessage(), ex);
		} finally {
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeStatement(statement);
			DBConnector.closeConnection(connection);
		}
		return coachList;
	}	
	
	/**
	 * Gets Coach from database by its primary key
	 * @param pk primary key of Coach
	 * @return Coach object
	 * @throws DatabaseException
	 */
	public Coach getByPK(int pk) throws DatabaseException {
		PreparedStatement statment = null;
		ResultSet resultSet = null;
		Coach coach = null;
		try {
			connection = DBConnector.getConnection();
			statment = connection.prepareStatement(GET_COACH_BY_PK);
			statment.setInt(1, pk);
			resultSet = statment.executeQuery();
			if (resultSet.next()) {
				coach = extract(resultSet);
			}
		} catch (SQLException ex) {
			LOG.error(ex.getMessage(), ex);
			throw new DatabaseException(ex.getMessage(), ex);
		} finally {
			DBConnector.closeStatement(statment);
			DBConnector.closeResultSet(resultSet);
			DBConnector.closeConnection(connection);
		}
		return coach;
	}
	/**
	 * Extracts a Coach object from the result set
	 * @param resultSet  Result set from which a coach will be extracted.
	 * @return Coach object
	 * @throws SQLException
	 * @throws DatabaseException
	 */
	private Coach extract(ResultSet resultSet) throws SQLException, DatabaseException {
		Coach coach = new Coach();
		CoachTypeDAO coachTypeDAO = new CoachTypeDAO();
		coach.setType(coachTypeDAO.getByPK(resultSet.getInt(Field.COACHTYPE_ID)));		
		coach.setId(resultSet.getInt(Field.COACH_ID));
		coach.setNumber(resultSet.getInt(Field.NUMBER));		
		return coach;
	}
	
}
