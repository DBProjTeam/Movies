package ua.nure.bobrov.SummaryTask4.database;

/**
 * Database fields
 * 
 * @author Bobrov Vyacheslav
 */
public final class Field {

	public static final String STATION_ID = "id_station";
	public static final String NAME = "name";

	public static final String ROUTEITEM_ID = "id_routeitem";
	
	public static final String ARRIVAL_TIME = "arrival_time";
	public static final String DEPARTURE_TIME = "departure_time";
	public static final String SEQUENCE_NUMBER = "sequence_number";
	
	public static final String ROUTE_ID = "id_route";
	public static final String BEGIN_TIME = "begin_time";
	public static final String END_TIME = "end_time";

	public static final String COACH_ID = "id_coach";
	public static final String NUMBER = "number";
	
	public static final String COACHTYPE_ID = "id_coachtype";
	public static final String PASSANGER_NUMBER = "passanger_number";
	public static final String PICTURE = "picture";
	public static final String COEFFICIENT = "coefficient";
	
	public static final String TRAIN_ID = "id_train";

	public static final String TRIP_ID = "id_trip";
	
	public static final String TICKET_ID = "id_ticket";
	public static final String BEGIN_STATION_ID = "id_begin_station";
	public static final String END_STATION_ID = "id_end_station";
	public static final String COACH_NUMBER = "coach_number";
	public static final String SEAT_NUMBER = "seat_number";
	public static final String PRICE = "price";
	public static final String DEPARTURE_DATE = "departure_date";	
	public static final String ARRIVAL_DATE = "arrival_date";
	
	public static final String USER_ID = "id_user";
	public static final String EMAIL = "email";
	public static final String PASSWORD = "password";
	public static final String SURNAME = "surname";	
	public static final String ROLE_ID = "id_role";
	public static final String BANNED = "banned";
	public static final String LANGUAGE = "language";	
	
	public static final String TOKEN = "token";	

}
