package ua.nure.bobrov.SummaryTask4.database.entity;

/**
 * Station entity
 * 
 * @author Bobrov Vyacheslav
 */
public class Station extends Entity{

	private static final long serialVersionUID = 4582320304096838436L;

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}	
	
}
