package ua.nure.bobrov.SummaryTask4.bean;

import java.io.Serializable;
import java.util.List;

import ua.nure.bobrov.SummaryTask4.database.entity.Station;

/**
 * Bean for transmitting result of trip searching
 * 
 * @author Bobrov Vyacheslav
 */
public class TripSearchResultBean implements Serializable {

	private static final long serialVersionUID = 4552432511138973435L;

	private int tripId;
	private String trainNumber;
	private Station departureStation;
	private Station arrivalStation;
	private TripDateTimeBean time;
	private List<SeatPriceBean> seatPriceBeans;

	public TripDateTimeBean getTime() {
		return time;
	}
	public void setTime(TripDateTimeBean time) {
		this.time = time;
	}
	public int getTripId() {
		return tripId;
	}
	public void setTripId(int tripId) {
		this.tripId = tripId;
	}
	public String getTrainNumber() {
		return trainNumber;
	}
	public void setTrainNumber(String trainName) {
		this.trainNumber = trainName;
	}
	public Station getDepartureStation() {
		return departureStation;
	}
	public void setDepartureStation(Station departureStation) {
		this.departureStation = departureStation;
	}
	public Station getArrivalStation() {
		return arrivalStation;
	}
	public void setArrivalStation(Station arrivalStation) {
		this.arrivalStation = arrivalStation;
	}
	public List<SeatPriceBean> getSeatPriceBeans() {
		return seatPriceBeans;
	}
	public void setSeatPriceBeans(List<SeatPriceBean> seatPriceBeans) {
		this.seatPriceBeans = seatPriceBeans;
	}
	public int getCoachTypeNumber() {
		return seatPriceBeans.size();
	}

	/**
	 * Bean for transmitting information about number of free seats in a certain
	 * type of coach, and price of ticket
	 * 
	 * @author Bobrov Vyacheslav
	 */
	public static class SeatPriceBean implements Serializable {

		private static final long serialVersionUID = -9215038772370243794L;

		private String coachType;
		private int freeSeatsNumber;
		private double price;

		public String getCoachType() {
			return coachType;
		}
		public void setCoachType(String coachType) {
			this.coachType = coachType;
		}
		public int getFreeSeatsNumber() {
			return freeSeatsNumber;
		}
		public void setFreeSeatsNumber(int freeSeatsNumber) {
			this.freeSeatsNumber = freeSeatsNumber;
		}
		public double getPrice() {
			return price;
		}
		public void setPrice(double price) {
			this.price = price;
		}

	}
}
