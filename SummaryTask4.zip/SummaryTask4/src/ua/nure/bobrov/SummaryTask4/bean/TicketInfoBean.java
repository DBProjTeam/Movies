package ua.nure.bobrov.SummaryTask4.bean;

import java.io.Serializable;
import java.sql.Timestamp;

import ua.nure.bobrov.SummaryTask4.database.entity.Station;
/**
 * Bean for transmitting ticket information
 * @author Bobrov Vyacheslav
 *
 */
public class TicketInfoBean implements Serializable{

	private static final long serialVersionUID = 610602927445414647L;
	
	private Station departureStation;
	private Station arrivalStation;
	private String coachType;
	private int coachNumber;
	private int seatNumber;
	private Timestamp departureDate;
	private Timestamp arrivalDate;
	private double price;
	
	public String getCoachType() {
		return coachType;
	}
	public void setCoachType(String coachType) {
		this.coachType = coachType;
	}
	public int getCoachNumber() {
		return coachNumber;
	}
	public void setCoachNumber(int coachNumber) {
		this.coachNumber = coachNumber;
	}
	public Station getDepartureStation() {
		return departureStation;
	}
	public void setDepartureStation(Station departureStation) {
		this.departureStation = departureStation;
	}
	public Station getArrivalStation() {
		return arrivalStation;
	}
	public void setArrivalStation(Station arrivalStation) {
		this.arrivalStation = arrivalStation;
	}
	public int getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Timestamp getDepartureDate() {
		return new Timestamp(departureDate.getTime());
	}
	public void setDepartureDate(Timestamp departureDate) {
		this.departureDate = new Timestamp(departureDate.getTime());
	}
	public Timestamp getArrivalDate() {
		return new Timestamp(arrivalDate.getTime());
	}
	public void setArrivalDate(Timestamp arrivalDate) {
		this.arrivalDate = new Timestamp(arrivalDate.getTime());
	}
	
}
