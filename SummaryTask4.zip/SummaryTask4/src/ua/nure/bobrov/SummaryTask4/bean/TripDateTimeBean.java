package ua.nure.bobrov.SummaryTask4.bean;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Bean for transmitting information about trip arrival, departure date, and
 * summary trip time
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class TripDateTimeBean implements Serializable {

	private static final long serialVersionUID = -4573319150044865305L;

	private Timestamp departureDate;
	/**
	 * Summary trip time
	 */
	private TripTime tripTime;
	private Timestamp arrivalDate;

	public Timestamp getDepartureDate() {
		return new Timestamp(departureDate.getTime());
	}

	public void setDepartureDate(Timestamp departureDate) {
		this.departureDate = new Timestamp(departureDate.getTime());
	}

	public TripTime getTripTime() {
		return tripTime;
	}

	public void setTripTime(TripTime tripTime) {
		this.tripTime = tripTime;
	}

	public Timestamp getArrivalDate() {
		return new Timestamp(arrivalDate.getTime());
	}

	public void setArrivalDate(Timestamp arrivalDate) {
		this.arrivalDate = new Timestamp(arrivalDate.getTime());
	}

	/**
	 * Holds number of days, hours and minutes in trip
	 * 
	 * @author Bobrov Vyacheslav
	 *
	 */
	public static class TripTime implements Serializable {

		private static final long serialVersionUID = 7144124064903463220L;

		private int days;
		private int hours;
		private int minutes;

		public int getDays() {
			return days;
		}
		public void setDays(int days) {
			this.days = days;
		}
		public int getHours() {
			return hours;
		}
		public void setHours(int hours) {
			this.hours = hours;
		}
		public int getMinutes() {
			return minutes;
		}
		public void setMinutes(int minutes) {
			this.minutes = minutes;
		}

	}
}
