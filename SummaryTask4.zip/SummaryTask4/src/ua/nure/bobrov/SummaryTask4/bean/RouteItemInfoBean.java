package ua.nure.bobrov.SummaryTask4.bean;

import java.io.Serializable;

/**
 * Bean for transmitting route information
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class RouteItemInfoBean implements Serializable {

	private static final long serialVersionUID = -526765612735948643L;

	private String station;
	private String departureTime;
	private String stopTime;
	private String arrivalTime;

	/**
	 * Constructs new object *
	 */
	public RouteItemInfoBean() {
	}
	/**
	 * Constructs new object with station name and string representation of
	 * arrival, stop and departure time
	 * 
	 * @param coach
	 * @param freeSeats
	 */
	public RouteItemInfoBean(String station, String arrivalTime, String stopTime, String departureTime) {
		this.station = station;
		this.departureTime = departureTime;
		this.stopTime = stopTime;
		this.arrivalTime = arrivalTime;
	}
	public String getStation() {
		return station;
	}
	public void setStation(String station) {
		this.station = station;
	}
	public String getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}
	public String getStopTime() {
		return stopTime;
	}
	public void setStopTime(String stopTime) {
		this.stopTime = stopTime;
	}
	public String getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

}
