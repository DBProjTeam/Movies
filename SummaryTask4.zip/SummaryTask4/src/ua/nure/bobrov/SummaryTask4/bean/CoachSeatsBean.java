package ua.nure.bobrov.SummaryTask4.bean;

import java.io.Serializable;

public class CoachSeatsBean implements Serializable{

	
	private static final long serialVersionUID = -9077342739014239901L;
	
	private int coachTypeId;
	private int seatNumber;
	
	
	public CoachSeatsBean(int coachTypeId, int seatNumber) {
		super();
		this.coachTypeId = coachTypeId;
		this.seatNumber = seatNumber;
	}
	
	public int getCoachTypeId() {
		return coachTypeId;
	}
	public void setCoachTypeId(int coachTypeId) {
		this.coachTypeId = coachTypeId;
	}
	public int getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}
	
}
