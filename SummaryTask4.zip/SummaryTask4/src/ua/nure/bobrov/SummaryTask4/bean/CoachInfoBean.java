package ua.nure.bobrov.SummaryTask4.bean;

import java.io.Serializable;
import java.util.List;

import ua.nure.bobrov.SummaryTask4.database.entity.Coach;

/**
 * Bean for transmitting coach information
 * 
 * @author Bobrov Vyacheslav
 */
public class CoachInfoBean implements Serializable {

	private static final long serialVersionUID = -7123131775932184346L;

	private Coach coach;
	/**
	 * List of free seats numbers in the coach
	 */
	private List<Integer> freeSeats;
	
	/**
	 * Constructs new object	 *
	 */
	public CoachInfoBean() {
	}
	/**
	 * Constructs new object with Coach and List of free seats numbers
	 * 
	 * @param coach
	 * @param freeSeats
	 */
	public CoachInfoBean(Coach coach, List<Integer> freeSeats) {
		this.coach = coach;
		this.freeSeats = freeSeats;
	}
	public Coach getCoach() {
		return coach;
	}
	public void setCoach(Coach coach) {
		this.coach = coach;
	}
	public int getFreeSeatsNumber() {
		return freeSeats.size();
	}
	public List<Integer> getFreeSeats() {
		return freeSeats;
	}
	public void setFreeSeats(List<Integer> freeSeats) {
		this.freeSeats = freeSeats;
	}
}
