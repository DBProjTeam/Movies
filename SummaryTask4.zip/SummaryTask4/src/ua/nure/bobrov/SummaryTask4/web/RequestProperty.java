package ua.nure.bobrov.SummaryTask4.web;

/**
 * Request attribute and parameter names
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class RequestProperty {

	public static final String LANGUAGE = "lang";
	public static final String TOKEN = "token";
	public static final String EMAIL = "email";
	public static final String PASSWORD = "password";
	public static final String PASSWORD2 = "password2";
	public static final String CAPTCHA = "g-recaptcha-response";
	public static final String NAME = "name";
	public static final String SURNAME = "surname";
	public static final String USER_MAP = "userMap";

	public static final String DEPARTURE_STATION_ID = "departureStationId";
	public static final String ARRIVAL_STATION_ID = "arrivalStationId";
	public static final String TRIP_ID = "tripId";
	public static final String COACH_ID = "coachId";
	public static final String SEAT = "seat";
	public static final String USER_ID = "userId";
	public static final String USER = "user";
	public static final String STATION_ID = "stationId";
	public static final String ROUTE_ID = "routeId";
	public static final String ROUTEITEM_ID = "routeItemId";
	public static final String TICKET_ID = "ticketId";

	public static final String SHOW_CAPTCHA = "showCaptcha";
	public static final String ERROR = "error";
	public static final String TICKETS = "tickets";
	public static final String COACHES = "coaches";
	public static final String COACHTYPES = "coachtypes";
	public static final String STATIONS = "stations";
	public static final String ROUTS = "routs";
	public static final String ROUTEITEMS = "routeItems";
	public static final String TRAINS = "trains";
	public static final String ROLES = "roles";
	public static final String ROUTE = "route";
	public static final String ROUTEITEM = "routeItem";
	public static final String STATION = "station";
	public static final String TRIP = "trip";
	public static final String TRIPS = "trips";
	public static final String LANGUAGES = "languages";
	public static final String EDITED_USER = "editedUser";
	public static final String USERS = "users";
	public static final String COACH_INFO_BEANS = "coachInfoBeans";
	public static final String ROUTE_INFO = "routeInfo";
	public static final String FROM = "from";
	public static final String TO = "to";
	public static final String DEPARTURE_DATE = "departureDate";
	public static final String SEARCH_RESULTS = "searchResults";
	public static final String BEGIN_STATION_ID = "beginStationId";
	public static final String END_STATION_ID = "endStationId";
	public static final String DEPARTURE_TIME = "departureTime";
	public static final String ARRIVAL_TIME = "arrivalTime";
	public static final String SEQUENCE_NUMBER = "sequenceNumber";
	public static final String TRAIN_ID = "trainId";
	public static final String ROLE_ID = "roleId";

}
