package ua.nure.bobrov.SummaryTask4.web.action.manager.ticket;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.TicketDAO;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.util.FieldValidator;
import ua.nure.bobrov.SummaryTask4.web.Message;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Delete ticket action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class DeleteTicketAction extends Action {

	private static final Logger LOG = Logger.getLogger(DeleteTicketAction.class);

	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		String ticketIdString = request.getParameter(RequestProperty.TICKET_ID);
		
		LOG.trace("Request parameter ticketId: " + ticketIdString);
		if (ticketIdString == null || !FieldValidator.isPositiveInteger(ticketIdString)) {
			request.setAttribute(RequestProperty.ERROR, Message.TICKET_NOT_SPECIFIED);
		} else {
			int ticketId = Integer.parseInt(ticketIdString);
			TicketDAO ticketDAO = new TicketDAO();
			if (ticketDAO.delete(ticketId)) {
				LOG.debug("Action is completed successfully");
				return new PageData("ticket_list", false);
			} else {
				request.setAttribute(RequestProperty.ERROR, Message.REMOVAL_IS_IMPOSSIBLE);
			}
		}
		LOG.debug("Action is completed with error");
		return new PageData(Path.ERROR_PAGE, true);
	}

}
