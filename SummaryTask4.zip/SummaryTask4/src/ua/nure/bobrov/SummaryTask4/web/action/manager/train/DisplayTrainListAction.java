package ua.nure.bobrov.SummaryTask4.web.action.manager.train;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.TrainDAO;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Display train list action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class DisplayTrainListAction extends Action {

	private static final Logger LOG = Logger.getLogger(DisplayTrainListAction.class);

	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		request.setAttribute(RequestProperty.TRAINS, (new TrainDAO()).findAll());
		LOG.debug("Action is completed successfully");
		return new PageData(Path.MANAGER_TRAINS, true);
	}

}
