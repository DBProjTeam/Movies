package ua.nure.bobrov.SummaryTask4.web.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
/**
 * Redirects to main search page
 * @author Bobrov Vyacheslav
 *
 */
public class IndexAction extends Action{

	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		return new PageData("controller/search_trip", false);
	}

}
