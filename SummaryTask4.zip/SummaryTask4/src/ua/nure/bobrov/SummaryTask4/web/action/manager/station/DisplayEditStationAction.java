package ua.nure.bobrov.SummaryTask4.web.action.manager.station;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.StationDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.Station;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.util.FieldValidator;
import ua.nure.bobrov.SummaryTask4.web.Message;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Display edit station action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class DisplayEditStationAction extends Action {

	private static final Logger LOG = Logger.getLogger(DisplayEditStationAction.class);
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		String stationIdString = request.getParameter(RequestProperty.STATION_ID);

		LOG.trace("Request parameter stationId: " + stationIdString);
		if (!FieldValidator.isPositiveInteger(stationIdString)) {
			request.setAttribute(RequestProperty.ERROR, Message.STATION_NOT_SPECIFIED);
		} else {
			int stationId = Integer.parseInt(stationIdString);
			StationDAO stationDAO = new StationDAO();
			Station station = stationDAO.getByPK(stationId);
			if (station == null) {
				request.setAttribute(RequestProperty.ERROR, Message.STATION_NOT_EXISTS);
			} else {
				request.setAttribute(RequestProperty.STATION, station);
				LOG.debug("Action is completed successfully");
				return new PageData(Path.MANAGER_EDIT_STATION, true);
			}
		}
		LOG.debug("Action is completed with error");
		return new PageData(Path.ERROR_PAGE, true);
	}

}
