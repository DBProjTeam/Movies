package ua.nure.bobrov.SummaryTask4.web.action.manager.route;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.RouteDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.StationDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.Route;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.util.FieldValidator;
import ua.nure.bobrov.SummaryTask4.web.Message;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Display edit route action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class DisplayEditRouteAction extends Action {

	private static final Logger LOG = Logger.getLogger(DisplayEditRouteAction.class);

	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");

		String routeIdString = request.getParameter(RequestProperty.ROUTE_ID);

		LOG.trace("Request parameter routeId: " + routeIdString);
		
		if (routeIdString == null || !FieldValidator.isPositiveInteger(routeIdString)) {
			request.setAttribute(RequestProperty.ERROR, Message.ROUTE_NOT_SPECIFIED);
		} else {
			int routeId = Integer.parseInt(routeIdString);
			RouteDAO routeDAO = new RouteDAO();
			Route route = routeDAO.getByPK(routeId);
			if (route == null) {
				request.setAttribute(RequestProperty.ERROR, Message.ROUTE_NOT_EXISTS);
			} else {
				request.setAttribute(RequestProperty.STATIONS, (new StationDAO()).findAll());
				request.setAttribute(RequestProperty.ROUTE, route);
				LOG.debug("Action is completed successfully");
				return new PageData(Path.MANAGER_EDIT_ROUTE, true);
			}
		}
		LOG.debug("Action is completed with error");
		return new PageData(Path.ERROR_PAGE, true);
	}

}
