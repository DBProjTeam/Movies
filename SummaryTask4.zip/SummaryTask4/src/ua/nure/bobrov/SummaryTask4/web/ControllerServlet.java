package ua.nure.bobrov.SummaryTask4.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;
import ua.nure.bobrov.SummaryTask4.web.action.container.ActionContainer;

/**
 * Main servlet controller
 * 
 * @author Bobrov Vyacheslav
 *
 */
@WebServlet("/controller/*")
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 6061918238589477381L;

	private static final Logger LOG = Logger.getLogger(ControllerServlet.class);

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		LOG.debug("Controller starts");
		Action action = ActionContainer.get(request);
		PageData pageData = null;
		try {
			pageData = action.execute(request, response);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			request.setAttribute(RequestProperty.ERROR, Message.SERVER_ERROR);
			pageData = new PageData(Path.ERROR_PAGE, true);
		}
		if (pageData.isForward()) {
			LOG.debug("Controller ends, forward: " + pageData.getPath());
			request.getRequestDispatcher(pageData.getPath()).forward(request, response);
		} else {
			LOG.debug("Controller ends, redirect: " + pageData.getPath());
			response.sendRedirect(pageData.getPath());
		}

	}

}
