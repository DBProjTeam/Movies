package ua.nure.bobrov.SummaryTask4.web.action.client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.bean.TicketInfoBean;
import ua.nure.bobrov.SummaryTask4.database.dao.CoachTypeDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.StationDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.TicketDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.CoachType;
import ua.nure.bobrov.SummaryTask4.database.entity.Ticket;
import ua.nure.bobrov.SummaryTask4.database.entity.User;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Display user tickets action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class DisplayUserTicketsAction extends Action {

	private static final Logger LOG = Logger.getLogger(DisplayUserTicketsAction.class);

	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {

		LOG.debug("Action starts");
		HttpSession session = request.getSession();
		User user = null;

		if ((user = (User) session.getAttribute(RequestProperty.USER)) != null) {
			TicketDAO ticketDAO = new TicketDAO();
			List<Ticket> ticketList = ticketDAO.findAllByUserId(user.getId());
			List<TicketInfoBean> ticketInfoBeans = new ArrayList<TicketInfoBean>();
			StationDAO stationDAO = new StationDAO();
			CoachTypeDAO coachTypeDAO = new CoachTypeDAO();
			for (Ticket ticket : ticketList) {
				TicketInfoBean ticketInfoBean = new TicketInfoBean();
				ticketInfoBean.setDepartureStation(stationDAO.getByPK(ticket.getDepartureStationId()));
				ticketInfoBean.setArrivalStation(stationDAO.getByPK(ticket.getArrivalStationId()));
				ticketInfoBean.setDepartureDate(ticket.getDepartureDate());
				ticketInfoBean.setArrivalDate(ticket.getArrivalDate());
				ticketInfoBean.setCoachNumber(ticket.getCoachNumber());
				ticketInfoBean.setSeatNumber(ticket.getSeatNumber());
				CoachType coachType = coachTypeDAO.getByPK(ticket.getCoachTypeId());
				ticketInfoBean.setCoachType(coachType.getName());
				ticketInfoBean.setPrice(ticket.getPrice());
				ticketInfoBeans.add(ticketInfoBean);
			}
			request.setAttribute(RequestProperty.TICKETS, ticketInfoBeans);
			LOG.debug("Action is completed successfully");
			return new PageData(Path.USER_TICKETS, true);
		}
		LOG.debug("Action is completed with error");
		return new PageData(Path.LOGIN_PAGE, true);
	}

}
