package ua.nure.bobrov.SummaryTask4.web.action.account;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.UserDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.User;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.util.FieldValidator;
import ua.nure.bobrov.SummaryTask4.web.Message;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;
import ua.nure.bobrov.SummaryTask4.web.service.CaptchaVerifyService;

/**
 * User login action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class LoginAction extends Action {

	private static final Logger LOG = Logger.getLogger(LoginAction.class);

	@SuppressWarnings("unchecked")
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {

		LOG.debug("Action starts");
		String email = request.getParameter(RequestProperty.EMAIL);
		String password = request.getParameter(RequestProperty.PASSWORD);
		boolean isNoError = true;
		
		LOG.trace("Request parameter email: " + email);
		LOG.trace("Request parameter password: " + password);
		
		if (!FieldValidator.isEmailValid(email)) {
			request.setAttribute(RequestProperty.ERROR,  Message.NOT_VALID_EMAIL);
		} else if (!FieldValidator.isPasswordValid(password)) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_PASSWORD);
		} else {
			/*�������� ������*/
			/*if (request.getSession().getAttribute(RequestProperty.SHOW_CAPTCHA) != null) {
				String gRecaptchaResponse = request.getParameter(RequestProperty.CAPTCHA);
				if (!CaptchaVerifyService.verifyCaptcha(gRecaptchaResponse)) {
					request.setAttribute(RequestProperty.ERROR, Message.WRONG_CAPTCHA);
					isNoError = false;
				} else {
					request.getSession().removeAttribute(RequestProperty.SHOW_CAPTCHA);
				}
			}*/
			if (isNoError) {
				UserDAO userDAO = new UserDAO();
				User user = userDAO.getByEmail(email);
				if (user == null || !user.getPassword().equals(password)) {
					request.setAttribute(RequestProperty.ERROR, Message.WRONG_EMAIL_PASSWORD);
				} else {
					HttpSession session = request.getSession();
					session.setAttribute(RequestProperty.USER, user);
					Map<Integer, HttpSession> userMap = (Map<Integer, HttpSession>) request.getServletContext().getAttribute(RequestProperty.USER_MAP);
					userMap.put(user.getId(), session);
					LOG.debug("Action is completed successfully");
					return new PageData("search_trip", false);
				}
			}
		}
		//request.getSession().setAttribute(RequestProperty.SHOW_CAPTCHA, "true");
		LOG.debug("Action is completed with error");
		return new PageData(Path.LOGIN_PAGE, true);
	}

}
