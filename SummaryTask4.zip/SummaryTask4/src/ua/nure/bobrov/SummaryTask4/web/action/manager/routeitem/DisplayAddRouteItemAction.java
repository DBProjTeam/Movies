package ua.nure.bobrov.SummaryTask4.web.action.manager.routeitem;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.RouteDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.StationDAO;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * 
 * Display add route item action
 *
 * @author Bobrov Vyacheslav
 *
 */
public class DisplayAddRouteItemAction extends Action {

	private static final Logger LOG = Logger.getLogger(DisplayAddRouteItemAction.class);
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		request.setAttribute(RequestProperty.STATIONS, (new StationDAO()).findAll());
		request.setAttribute(RequestProperty.ROUTS, (new RouteDAO()).findAll());	
		LOG.debug("Action is completed successfully");
		return new PageData(Path.MANAGER_ADD_ROUTEITEM, true);
	}

}
