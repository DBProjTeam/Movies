package ua.nure.bobrov.SummaryTask4.web.action.manager.user;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.enums.Language;
import ua.nure.bobrov.SummaryTask4.enums.RoleType;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Display add user action
 * @author Bobrov Vyacheslav
 *
 */
public class DisplayAddUserAction extends Action {

	private static final Logger LOG = Logger.getLogger(DisplayAddUserAction.class);

	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		List<RoleType> roleTypes = new ArrayList<RoleType>(Arrays.asList(RoleType.values()));
		roleTypes.remove(RoleType.ADMIN);
		request.setAttribute(RequestProperty.ROLES, roleTypes);
		request.setAttribute(RequestProperty.LANGUAGES, Language.values());
		LOG.debug("Action is completed successfully");
		return new PageData(Path.ADMIN_ADD_USER, true);
	}

}
