package ua.nure.bobrov.SummaryTask4.web.action.client;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.bean.TripDateTimeBean;
import ua.nure.bobrov.SummaryTask4.database.dao.CoachDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.RouteDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.RouteItemDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.TicketDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.TripDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.Coach;
import ua.nure.bobrov.SummaryTask4.database.entity.Route;
import ua.nure.bobrov.SummaryTask4.database.entity.RouteItem;
import ua.nure.bobrov.SummaryTask4.database.entity.Ticket;
import ua.nure.bobrov.SummaryTask4.database.entity.Trip;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.web.Message;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;
import ua.nure.bobrov.SummaryTask4.web.service.TripSearchService;

/**
 * Ticket buying action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class BuyTicketAction extends Action {

	private static final Logger LOG = Logger.getLogger(BuyTicketAction.class);

	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {

		LOG.debug("Action starts");

		int departureStationId = Integer.parseInt(request.getParameter(RequestProperty.DEPARTURE_STATION_ID));
		int arrivalStationId = Integer.parseInt(request.getParameter(RequestProperty.ARRIVAL_STATION_ID));
		int tripId = Integer.parseInt(request.getParameter(RequestProperty.TRIP_ID));
		int coachId = Integer.parseInt(request.getParameter(RequestProperty.COACH_ID));
		int seat = Integer.parseInt(request.getParameter(RequestProperty.SEAT));
		int userId = Integer.parseInt(request.getParameter(RequestProperty.USER_ID));

		TripDAO tripDAO = new TripDAO();
		Trip trip = tripDAO.getByPK(tripId);
		if (trip != null) {

			RouteDAO routeDAO = new RouteDAO();
			Route route = routeDAO.getByPK(trip.getRouteId());

			RouteItemDAO routeItemDAO = new RouteItemDAO();
			List<RouteItem> routeItems = routeItemDAO.findAllByRouteId(route.getId());
			TripDateTimeBean time = TripSearchService.getTripDateTimeBean(routeItems, route, departureStationId,
					arrivalStationId, trip.getDepartureDate());
			if (time != null) {
				CoachDAO coachDAO = new CoachDAO();
				Coach coach = coachDAO.getByPK(coachId);

				TicketDAO ticketDAO = new TicketDAO();
				List<Ticket> tickets = ticketDAO.findAllByDateRange(tripId, time.getDepartureDate(),
						time.getArrivalDate());
				for (Ticket ticket : tickets) {
					if ((ticket.getCoachNumber() == coach.getNumber()) && (ticket.getSeatNumber() == seat)) {
						request.setAttribute(RequestProperty.ERROR, Message.TICKET_BOUGHT);
						LOG.debug("Action is completed with error");
						return new PageData(Path.ERROR_PAGE, true);
					}
				}
				Ticket ticket = new Ticket();
				ticket.setTripId(tripId);
				ticket.setUserId(userId);
				ticket.setDepartureStationId(departureStationId);
				ticket.setArrivalStationId(arrivalStationId);
				ticket.setCoachNumber(coach.getNumber());
				ticket.setCoachTypeId(coach.getType().getId());
				ticket.setSeatNumber(seat);
				ticket.setDepartureDate(time.getDepartureDate());
				ticket.setArrivalDate(time.getArrivalDate());
				ticket.setPrice(TripSearchService.getPrice(time.getTripTime(), coach.getType().getCoefficient()));
				ticketDAO.insert(ticket);

				LOG.debug("Action is completed successfully");
				return new PageData("user_tickets", false);
			}
		}
		request.setAttribute(RequestProperty.ERROR, Message.TRIP_NOT_EXISTS);
		LOG.debug("Action is completed with error");
		return new PageData(Path.ERROR_PAGE, true);
	}

}
