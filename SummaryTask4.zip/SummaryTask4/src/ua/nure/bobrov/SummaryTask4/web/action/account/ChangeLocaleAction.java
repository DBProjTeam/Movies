package ua.nure.bobrov.SummaryTask4.web.action.account;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.jstl.core.Config;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.enums.Language;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.util.MessageManager;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;
/**
 * Change locale action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class ChangeLocaleAction extends Action {

	private static final Logger LOG = Logger.getLogger(ChangeLocaleAction.class);
	
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		
		LOG.debug("Action starts");
		
		String language = request.getParameter(RequestProperty.LANGUAGE);
		String referer = request.getHeader("Referer"); 
		
		LOG.trace("Request parameter language: " + language);
		
		HttpSession session = request.getSession();
		switch (language) {
		case "en":
			Config.set(session, Config.FMT_LOCALE, Language.ENGLISH.getLocale());
			MessageManager.setLocale(Language.ENGLISH.getLocale());
			break;
		case "ru":
			Config.set(session, Config.FMT_LOCALE, Language.RUSSIAN.getLocale());
			MessageManager.setLocale(Language.RUSSIAN.getLocale());
			break;
		default:
			Config.set(session, Config.FMT_LOCALE, Language.RUSSIAN.getLocale());
			MessageManager.setLocale(Language.RUSSIAN.getLocale());
			break;
		}
		
		LOG.debug("Action is complited successfully");
		return new PageData(referer, false);
	}

}
