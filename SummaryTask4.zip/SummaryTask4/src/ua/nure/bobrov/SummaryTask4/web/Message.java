package ua.nure.bobrov.SummaryTask4.web;

/**
 * Page messages
 * 
 * @author Bobrov Vyacheslav
 *
 */
public final class Message {
	
	public static final String STATION_NOT_EXISTS = "error.station.not.exists";
	public static final String REMOVAL_IS_IMPOSSIBLE = "error.removal.impossible";
	public static final String STATION_NOT_SPECIFIED = "error.station.not.specified";
	
	public static final String ROUTE_NOT_EXISTS = "error.route.not.exists";
	public static final String ROUTE_NOT_SPECIFIED = "error.route.not.specified";
	
	public static final String ROUTEITEM_NOT_EXISTS = "error.routeitem.not.exists";
	public static final String ROUTEITEM_NOT_SPECIFIED = "error.routeitem.not.specified";
	
	public static final String TICKET_NOT_SPECIFIED = "error.ticket.not.specified";
	
	public static final String TRIP_NOT_EXISTS = "error.trip.not.exists";
	public static final String TRIP_NOT_SPECIFIED = "error.trip.not.specified";
	
	public static final String USER_NOT_EXISTS = "error.user.not.exists";
	public static final String USER_NOT_SPECIFIED = "error.user.not.specified";
	
	public static final String NOT_VALID_PASSWORD = "error.not.valid.password";
	public static final String NOT_VALID_EMAIL = "error.not.valid.email";
	public static final String NOT_VALID_NAME_SURNAME = "error.not.valid.name";
	public static final String WRONG_CAPTCHA= "error.wrong.captcha";
	public static final String WRONG_EMAIL_PASSWORD= "error.wrong.email.password"; 
	public static final String PASSWORDS_NOT_MATCH= "error.passwords.not.match"; 
	public static final String USER_EXISTS= "error.user.exists"; 
	public static final String NOT_VALID_DATE= "error.not.valid.date";
	public static final String STATION_NOT_FOUND= "error.station.not.found";
	
	public static final String WRONG_STATION_NAME= "error.wrong.station.name";
	public static final String STATION_EXISTS= "error.station.exists";
	public static final String NOT_VALID_STATION_ID= "error.not.valid.station.id";
	public static final String NOT_VALID_ROUTE_ID= "error.not.valid.route.id";
	public static final String NOT_VALID_NUMBER= "error.not.valid.number";
	public static final String NOT_VALID_TIME= "error.not.valid.time";
	public static final String STATIONS_EQUAL= "error.stations.equal"; 
	public static final String ROUTE_EXISTS= "error.route.exists"; 
	public static final String STATION_IN_ROUTE= "error.station.in.route";
	public static final String ROUTEITEM_EXISTS= "error.routeitem.exists"; 
	public static final String NOT_VALID_TRAIN_ID= "error.not.valid.train.id";
	public static final String TRAIN_NOT_EXISTS= "error.train.not.exists";
	public static final String TRIP_EXISTS= "error.trip.exists";
	public static final String NOT_VALID_ROLE= "error.not.valid.role";
	public static final String CONFIRMATION_NOT_AVALIABLE= "error.confirmation.not.avaliable";
	public static final String USER_IS_BANNED = "error.user.banned";
	public static final String TICKET_BOUGHT = "error.ticket.bought";
	
	public static final String DATE_BEFORE_TODAY = "error.date.before.today";
	public static final String SERVER_ERROR = "error.server";

	public static final String CONFIRMATION_SUBJECT = "confirmation.subject";
	public static final String CONFIRMATION_MESSAGE = "confirmation.message";
	public static final String CONTACT_US ="footer.contact";
	public static final String AUTHOR ="footer.author";
	
}
