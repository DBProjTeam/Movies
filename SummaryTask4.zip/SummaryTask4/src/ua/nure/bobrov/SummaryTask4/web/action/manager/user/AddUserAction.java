package ua.nure.bobrov.SummaryTask4.web.action.manager.user;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.UserDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.User;
import ua.nure.bobrov.SummaryTask4.enums.Language;
import ua.nure.bobrov.SummaryTask4.enums.RoleType;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.util.EntityExtractor;
import ua.nure.bobrov.SummaryTask4.web.Message;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;
import ua.nure.bobrov.SummaryTask4.web.action.manager.ticket.DisplayTicketListAction;

/**
 * Add user action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class AddUserAction extends Action {

	private static final Logger LOG = Logger.getLogger(DisplayTicketListAction.class);

	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		User user = EntityExtractor.extractUser(request);
		if (user != null) {
			UserDAO userDAO = new UserDAO();
			if (userDAO.getByEmail(user.getEmail()) != null) {
				request.setAttribute(RequestProperty.ERROR, Message.USER_EXISTS);
			} else {
				userDAO.insert(user);
				LOG.debug("Action is completed successfully");
				return new PageData("user_list", false);
			}
		}
		List<RoleType> roleTypes = new ArrayList<RoleType>(Arrays.asList(RoleType.values()));
		roleTypes.remove(RoleType.ADMIN);
		request.setAttribute(RequestProperty.ROLES, roleTypes);
		request.setAttribute(RequestProperty.LANGUAGES, Language.values());
		LOG.debug("Action is completed with error");
		return new PageData(Path.ADMIN_ADD_USER, true);
	}

}
