package ua.nure.bobrov.SummaryTask4.web.listener;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.jstl.core.Config;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import ua.nure.bobrov.SummaryTask4.enums.Language;
import ua.nure.bobrov.SummaryTask4.util.MessageManager;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
/**
 * 
 * Context listener
 * 
 * @author Bobrov Vyacheslav
 *
 */
@WebListener
public class ContextListener implements ServletContextListener {

	private static final Logger LOG = Logger.getLogger(ContextListener.class);

	public ContextListener() {
		
	}

	public void contextDestroyed(ServletContextEvent sce) {
		LOG.debug("Context destroyed");
	}

	public void contextInitialized(ServletContextEvent sce) {
		try {
			Class.forName("ua.nure.bobrov.SummaryTask4.web.action.container.ActionContainer");
		} catch (ClassNotFoundException ex) {
			throw new IllegalStateException("Cannot initialize Action Container");
		}
		ServletContext context = sce.getServletContext();
		PropertyConfigurator.configure(context.getRealPath("/WEB-INF/log4jConfiguration.properties"));
		LOG.debug("Log4j has been initialized");
		setLocale(context);
		createUserMap(context);
		
		LOG.debug("Context has been initialized");
	}
	/**
	 * Creates user map that holds authorized users
	 * @param sce
	 */
	private void createUserMap(ServletContext context) {
		Map<Integer, HttpSession> userMap = new HashMap<Integer, HttpSession>();
		context.setAttribute(RequestProperty.USER_MAP, userMap);
		LOG.debug("User map has been created");
	}
	
	private void setLocale(ServletContext context) {
		Config.set(context, Config.FMT_LOCALE, Language.RUSSIAN.getLocale());
		MessageManager.setLocale(Language.RUSSIAN.getLocale());
		LOG.debug("Defaul locale has been set");
	}

}
