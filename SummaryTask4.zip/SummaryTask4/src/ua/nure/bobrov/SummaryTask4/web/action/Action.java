package ua.nure.bobrov.SummaryTask4.web.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;

/**
 * Abstract class for the Command pattern implementation.
 * 
 * @author Bobrov Vyacheslav
 *
 */
public abstract class Action {

	/**
	 * Returns object, which contains address to go once the action is executed
	 * @return PageData 
	 */
	public abstract PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException;

	@Override
	public String toString() {
		return getClass().getSimpleName();
	}
	
}
