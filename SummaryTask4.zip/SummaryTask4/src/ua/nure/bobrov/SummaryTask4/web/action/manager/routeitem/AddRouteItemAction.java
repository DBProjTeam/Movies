package ua.nure.bobrov.SummaryTask4.web.action.manager.routeitem;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.RouteDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.RouteItemDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.StationDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.RouteItem;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.util.EntityExtractor;
import ua.nure.bobrov.SummaryTask4.web.Message;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Add route item action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class AddRouteItemAction extends Action {

	private static final Logger LOG = Logger.getLogger(AddRouteItemAction.class);

	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		RouteDAO routeDAO = new RouteDAO();
		StationDAO stationDAO = new StationDAO();
		RouteItem routeItem = EntityExtractor.extractRouteItem(request, stationDAO, routeDAO);
		if (routeItem != null) {
			RouteItemDAO routeItemDAO = new RouteItemDAO();
			if (routeItemDAO.exists(routeItem)) {
				request.setAttribute(RequestProperty.ERROR, Message.ROUTEITEM_EXISTS);
			} else {
				routeItemDAO.insert(routeItem);
				LOG.debug("Action is completed successfully");
				return new PageData("routeitem_list", false);
			}
		}
		request.setAttribute(RequestProperty.STATIONS, stationDAO.findAll());
		request.setAttribute(RequestProperty.ROUTS, routeDAO.findAll());
		LOG.debug("Action is completed with error");
		return new PageData(Path.MANAGER_ADD_ROUTEITEM, true);
	}

}
