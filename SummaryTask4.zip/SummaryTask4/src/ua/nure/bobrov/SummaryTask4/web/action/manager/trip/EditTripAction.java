package ua.nure.bobrov.SummaryTask4.web.action.manager.trip;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.RouteDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.TrainDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.TripDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.Trip;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.util.EntityExtractor;
import ua.nure.bobrov.SummaryTask4.web.Message;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Edit trip action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class EditTripAction extends Action {

	private static final Logger LOG = Logger.getLogger(EditTripAction.class);

	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		int tripId = Integer.parseInt(request.getParameter(RequestProperty.TRIP_ID));
		
		LOG.trace("Request parameter tripId: " + tripId);
		
		TrainDAO trainDAO = new TrainDAO();
		RouteDAO routeDAO = new RouteDAO();
		TripDAO tripDAO = new TripDAO();
		Trip trip = EntityExtractor.extractTrip(request, trainDAO, routeDAO);

		if (trip != null) {
			trip.setId(tripId);
			if (!tripDAO.update(trip)) {
				request.setAttribute(RequestProperty.ERROR, Message.TRIP_NOT_EXISTS);
				LOG.debug("Action is completed with error");
				return new PageData(Path.ERROR_PAGE, true);
			} else {
				LOG.debug("Action is completed successfully");
				return new PageData("trip_list", false);
			}
		}
		request.setAttribute(RequestProperty.ROUTS, routeDAO.findAll());
		request.setAttribute(RequestProperty.TRAINS, trainDAO.findAll());
		request.setAttribute(RequestProperty.TRIP, tripDAO.getByPK(tripId));
		LOG.debug("Action is completed with error");
		return new PageData(Path.MANAGER_EDIT_TRIP, true);

	}

}
