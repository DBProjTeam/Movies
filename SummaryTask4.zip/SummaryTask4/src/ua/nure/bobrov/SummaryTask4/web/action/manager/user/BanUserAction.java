package ua.nure.bobrov.SummaryTask4.web.action.manager.user;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.UserDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.User;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.util.FieldValidator;
import ua.nure.bobrov.SummaryTask4.web.Message;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Ban user action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class BanUserAction extends Action {

	private static final Logger LOG = Logger.getLogger(BanUserAction.class);

	@SuppressWarnings("unchecked")
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		String userIdString = request.getParameter(RequestProperty.USER_ID);
		
		LOG.trace("Request parameter userId: " + userIdString);
		
		if (!FieldValidator.isPositiveInteger(userIdString)) {
			request.setAttribute(RequestProperty.ERROR, Message.USER_NOT_SPECIFIED);
		} else {
			int userId = Integer.parseInt(userIdString);
			UserDAO userDAO = new UserDAO();
			User user = userDAO.getByPK(userId);
			if (user == null) {
				request.setAttribute(RequestProperty.ERROR, Message.USER_NOT_EXISTS);
			} else {
				user.setBanned(!user.isBanned());
				userDAO.update(user);
				Map<Integer, HttpSession> userMap = (Map<Integer, HttpSession>) request.getServletContext()
						.getAttribute(RequestProperty.USER_MAP);
				HttpSession userSession = userMap.get(user.getId());
				if (userSession != null) {
					((User) userSession.getAttribute(RequestProperty.USER)).setBanned(user.isBanned());
				}
				LOG.debug("Action is completed successfully");
				return new PageData("user_list", false);
			}
		}
		LOG.debug("Action is completed with error");
		return new PageData(Path.ERROR_PAGE, true);
	}

}
