package ua.nure.bobrov.SummaryTask4.web.action.manager.ticket;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.TicketDAO;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Display ticket list action
 * @author Bobrov Vyacheslav
 *
 */
public class DisplayTicketListAction extends Action{

	private static final Logger LOG = Logger.getLogger(DisplayTicketListAction.class);
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		TicketDAO ticketDAO = new TicketDAO();
		request.setAttribute(RequestProperty.TICKETS, ticketDAO.findAll());	
		LOG.debug("Action is completed successfully");
		return new PageData(Path.MANAGER_TICKETS, true);
	}

}
