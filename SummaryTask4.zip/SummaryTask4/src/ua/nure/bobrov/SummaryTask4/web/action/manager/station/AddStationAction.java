package ua.nure.bobrov.SummaryTask4.web.action.manager.station;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.StationDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.Station;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.util.EntityExtractor;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Add station action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class AddStationAction extends Action {

	private static final Logger LOG = Logger.getLogger(AddStationAction.class);
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		StationDAO stationDAO = new StationDAO();
		Station station = EntityExtractor.extractStation(request, stationDAO);
		if (station != null) {			
			stationDAO.insert(station);
			LOG.debug("Action is completed successfully");
			return new PageData("station_list", false);
		}
		LOG.debug("Action is completed with error");
		return new PageData(Path.MANAGER_ADD_STATION, true);
	}

}
