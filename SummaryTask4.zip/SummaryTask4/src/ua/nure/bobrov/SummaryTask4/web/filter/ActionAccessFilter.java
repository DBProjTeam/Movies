package ua.nure.bobrov.SummaryTask4.web.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import ua.nure.bobrov.SummaryTask4.database.entity.User;
import ua.nure.bobrov.SummaryTask4.enums.RoleType;
import ua.nure.bobrov.SummaryTask4.web.Message;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;

/**
 * Action access filter
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class ActionAccessFilter implements Filter {

	/**
	 * Map contains user role as key and list of actions as value
	 */
	private Map<RoleType, List<String>> accessMap = new HashMap<RoleType, List<String>>();
	/**
	 * List of actions which are available to every registered user
	 */
	private List<String> commonActions = new ArrayList<String>();
	/**
	 * List of actions which are available to every user
	 */
	private List<String> outOfControlActions = new ArrayList<String>();

	public ActionAccessFilter() {
	}

	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		if (isAccessAllowed(request)) {
			chain.doFilter(request, response);
		} else {
			request.getRequestDispatcher(Path.ERROR_PAGE).forward(request, response);
		}
	}
	/**
	 * Checks if user can access action
	 * @param request
	 * @return true if user can access action, false otherwise
	 */
	private boolean isAccessAllowed(ServletRequest request) {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		String actionName = httpRequest.getPathInfo().substring(1);
		if (actionName == null || actionName.isEmpty()) {
			return false;
		}
		if (outOfControlActions.contains(actionName)) {
			return true;
		}
		HttpSession session = httpRequest.getSession(false);
		if (session == null) {
			return false;
		}
		User user = (User) session.getAttribute(RequestProperty.USER);
		if (user == null) {			
			return false;
		}
		if(!commonActions.contains(actionName) && user.isBanned()) {
			request.setAttribute(RequestProperty.ERROR, Message.USER_IS_BANNED);
			return false;
		}
		if (user.getRole().equals(RoleType.ADMIN)) {
			return accessMap.get(RoleType.ADMIN).contains(actionName)
					|| accessMap.get(RoleType.MANAGER).contains(actionName) || commonActions.contains(actionName);
		} else {
			return accessMap.get(user.getRole()).contains(actionName) || commonActions.contains(actionName);
		}

	}

	public void init(FilterConfig fConfig) throws ServletException {
		accessMap.put(RoleType.ADMIN, asList(fConfig.getInitParameter("admin")));
		accessMap.put(RoleType.MANAGER, asList(fConfig.getInitParameter("manager")));
		accessMap.put(RoleType.CLIENT, asList(fConfig.getInitParameter("client")));		
		commonActions = asList(fConfig.getInitParameter("common"));
		outOfControlActions = asList(fConfig.getInitParameter("outOfControl"));
	}
	/**
	 * Extracts list of action names from init parameter
	 * @param str
	 * @return
	 */
	private List<String> asList(String str) {
		List<String> list = new ArrayList<String>();
		StringTokenizer st = new StringTokenizer(str);
		while (st.hasMoreTokens()) {
			list.add(st.nextToken());
		}
		return list;
	}
}
