package ua.nure.bobrov.SummaryTask4.web.action.container;

import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;

import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.DisplayAvailableCoachesAction;
import ua.nure.bobrov.SummaryTask4.web.action.IndexAction;
import ua.nure.bobrov.SummaryTask4.web.action.RouteInfoAction;
import ua.nure.bobrov.SummaryTask4.web.action.RouteStatisticAction;
import ua.nure.bobrov.SummaryTask4.web.action.SearchTripsAction;
import ua.nure.bobrov.SummaryTask4.web.action.ViewPageAction;
import ua.nure.bobrov.SummaryTask4.web.action.account.ChangeLocaleAction;
import ua.nure.bobrov.SummaryTask4.web.action.account.ConfirmationAction;
import ua.nure.bobrov.SummaryTask4.web.action.account.EditUserPasswordAction;
import ua.nure.bobrov.SummaryTask4.web.action.account.EditUserProfileAction;
import ua.nure.bobrov.SummaryTask4.web.action.account.LogOutAction;
import ua.nure.bobrov.SummaryTask4.web.action.account.LoginAction;
import ua.nure.bobrov.SummaryTask4.web.action.account.RegistrationAction;
import ua.nure.bobrov.SummaryTask4.web.action.client.BuyTicketAction;
import ua.nure.bobrov.SummaryTask4.web.action.client.DisplayUserTicketsAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.coach.DisplayCoachListAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.coach.DisplayCoachTypeListAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.route.AddRouteAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.route.DeleteRouteAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.route.DisplayAddRouteAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.route.DisplayEditRouteAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.route.DisplayRouteListAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.route.EditRouteAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.routeitem.AddRouteItemAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.routeitem.DeleteRouteItemAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.routeitem.DisplayAddRouteItemAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.routeitem.DisplayEditRouteItemAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.routeitem.DisplayRouteItemListAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.routeitem.EditRouteItemAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.station.AddStationAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.station.DeleteStationAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.station.DisplayEditStationAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.station.DisplayStationListAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.station.EditStationAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.ticket.DeleteTicketAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.ticket.DisplayTicketListAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.train.DisplayTrainListAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.trip.AddTripAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.trip.DeleteTripAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.trip.DisplayAddTripAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.trip.DisplayEditTripAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.trip.DisplayTripListAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.trip.EditTripAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.user.AddUserAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.user.BanUserAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.user.DeleteUserAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.user.DisplayAddUserAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.user.DisplayUnconfirmedUserListAction;
import ua.nure.bobrov.SummaryTask4.web.action.manager.user.DisplayUserListAction;

/**
 * Holdar of all actions
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class ActionContainer {

	private static Map<String, Action> actions = new TreeMap<String, Action>();

	static {
		
		actions.put("GET/statistics", new RouteStatisticAction());
		
		actions.put("GET/avaliable_trips", new SearchTripsAction());
		actions.put("GET/route_info", new RouteInfoAction());	
		actions.put("GET/avaliable_coaches", new DisplayAvailableCoachesAction());
		actions.put("GET/login", new ViewPageAction(Path.LOGIN_PAGE));
		actions.put("GET/registration", new ViewPageAction(Path.REGISTRATION_PAGE));
		actions.put("GET/index", new IndexAction());
		actions.put("POST/login", new LoginAction());
		actions.put("POST/registration", new RegistrationAction());
		actions.put("GET/confirmation", new ConfirmationAction());
		actions.put("GET/confirmation_info", new ViewPageAction(Path.CONFIRMATION_INFO));
		actions.put("GET/logout", new LogOutAction());
		actions.put("GET/search_trip", new ViewPageAction(Path.SEARCH_TRIP));
		actions.put("GET/user_profile", new ViewPageAction(Path.USER_PROFILE));
		actions.put("GET/edit_password", new ViewPageAction(Path.EDIT_PASSWORD));
		actions.put("POST/edit_user_profile", new EditUserProfileAction());
		actions.put("POST/edit_password", new EditUserPasswordAction());
				
		actions.put("GET/station_list", new DisplayStationListAction());
		actions.put("GET/add_station", new ViewPageAction(Path.MANAGER_ADD_STATION));
		actions.put("POST/add_station", new AddStationAction());
		actions.put("GET/edit_station", new DisplayEditStationAction());
		actions.put("POST/edit_station", new EditStationAction());
		actions.put("GET/delete_station", new DeleteStationAction());
		
		actions.put("GET/route_list", new DisplayRouteListAction());
		actions.put("GET/add_route", new DisplayAddRouteAction());
		actions.put("POST/add_route", new AddRouteAction());
		actions.put("GET/edit_route", new DisplayEditRouteAction());
		actions.put("POST/edit_route", new EditRouteAction());
		actions.put("GET/delete_route", new DeleteRouteAction());
		
		actions.put("GET/routeitem_list", new DisplayRouteItemListAction());
		actions.put("GET/add_routeitem", new DisplayAddRouteItemAction());
		actions.put("POST/add_routeitem", new AddRouteItemAction());
		actions.put("GET/edit_routeitem", new DisplayEditRouteItemAction());
		actions.put("POST/edit_routeitem", new EditRouteItemAction());
		actions.put("GET/delete_routeitem", new DeleteRouteItemAction());
		
		actions.put("GET/train_list", new DisplayTrainListAction());
		
		actions.put("GET/coach_list", new DisplayCoachListAction());
		
		actions.put("GET/coachtype_list", new DisplayCoachTypeListAction());
		
		actions.put("GET/trip_list", new DisplayTripListAction());
		actions.put("GET/add_trip", new DisplayAddTripAction());
		actions.put("POST/add_trip", new AddTripAction());
		actions.put("GET/edit_trip", new DisplayEditTripAction());
		actions.put("POST/edit_trip", new EditTripAction());
		actions.put("GET/delete_trip", new DeleteTripAction());
		
		actions.put("GET/user_list", new DisplayUserListAction());
		actions.put("GET/add_user", new DisplayAddUserAction());
		actions.put("POST/add_user", new AddUserAction());
		actions.put("GET/ban_user", new BanUserAction());
		actions.put("GET/delete_user", new DeleteUserAction());
		actions.put("GET/unconfirmed_user_list", new DisplayUnconfirmedUserListAction());
		
		actions.put("GET/ticket_list", new DisplayTicketListAction());
		actions.put("GET/delete_ticket", new DeleteTicketAction());
		
		actions.put("POST/buy_ticket", new BuyTicketAction());
		actions.put("GET/user_tickets", new DisplayUserTicketsAction());
		
		actions.put("GET/set_language", new ChangeLocaleAction());
		
		actions.put("GET/no_action", new ViewPageAction(Path.ERROR_PAGE));
	}
	
	/**
	 * Returns action object with the name extracted from request.
	 * @param request 
	 * @return action
	 */
	public static Action get(HttpServletRequest request) {
		String actionName = request.getMethod() + request.getPathInfo();
		if (!actions.containsKey(actionName)) {
			return actions.get("GET/no_action");
		}
		return actions.get(actionName);
	}
}
