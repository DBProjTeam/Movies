package ua.nure.bobrov.SummaryTask4.web.action.manager.user;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.UnconfirmedUserDAO;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;
import ua.nure.bobrov.SummaryTask4.web.action.manager.ticket.DisplayTicketListAction;

/**
 * Display unconfirmed user list action
 * @author Bobrov Vyacheslav
 *
 */
public class DisplayUnconfirmedUserListAction extends Action{

	private static final Logger LOG = Logger.getLogger(DisplayTicketListAction.class);
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		UnconfirmedUserDAO unconfirmedUserDAO = new UnconfirmedUserDAO();
		request.setAttribute(RequestProperty.USERS, unconfirmedUserDAO.findAll());
		LOG.debug("Action is completed with error");
		return new PageData(Path.ADMIN_UNCONFIRMED_USERS, true);
	}

}
