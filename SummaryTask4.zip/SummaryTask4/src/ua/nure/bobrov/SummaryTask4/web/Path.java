package ua.nure.bobrov.SummaryTask4.web;

/**
 * Web pages paths
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class Path {

	public static final String INDEX_PAGE = "/WEB-INF/jsp/index.jsp";
	public static final String LOGIN_PAGE = "/WEB-INF/jsp/account/login.jsp";
	public static final String REGISTRATION_PAGE = "/WEB-INF/jsp/account/registration.jsp";
	public static final String CONFIRMATION_INFO = "/WEB-INF/jsp/confirmation_info.jsp";
	public static final String TRIP_LIST = "/WEB-INF/jsp/avaliable_trips.jsp";
	public static final String ROUTE_INFO = "/WEB-INF/jsp/route_info.jsp";
	public static final String COACH_LIST = "/WEB-INF/jsp/avaliable_coaches.jsp";
	public static final String SEARCH_TRIP = "/WEB-INF/jsp/search_trip.jsp";
	public static final String USER_TICKETS = "/WEB-INF/jsp/user_tickets.jsp";
	public static final String USER_PROFILE = "/WEB-INF/jsp/account/user_profile.jsp";
	public static final String EDIT_PASSWORD = "/WEB-INF/jsp/account/edit_password.jsp";

	public static final String MANAGER_MAIN = "/WEB-INF/jsp/manager/manager_main.jsp";

	public static final String MANAGER_STATIONS = "/WEB-INF/jsp/manager/station/stations.jsp";
	public static final String MANAGER_ADD_STATION = "/WEB-INF/jsp/manager/station/add_station.jsp";
	public static final String MANAGER_EDIT_STATION = "/WEB-INF/jsp/manager/station/edit_station.jsp";

	public static final String MANAGER_ROUTS = "/WEB-INF/jsp/manager/route/routs.jsp";
	public static final String MANAGER_ADD_ROUTE = "/WEB-INF/jsp/manager/route/add_route.jsp";
	public static final String MANAGER_EDIT_ROUTE = "/WEB-INF/jsp/manager/route/edit_route.jsp";

	public static final String MANAGER_ROUTITEMS = "/WEB-INF/jsp/manager/routeitem/routeitems.jsp";
	public static final String MANAGER_ADD_ROUTEITEM = "/WEB-INF/jsp/manager/routeitem/add_routeitem.jsp";
	public static final String MANAGER_EDIT_ROUTEITEM = "/WEB-INF/jsp/manager/routeitem/edit_routeitem.jsp";

	public static final String MANAGER_TRAINS = "/WEB-INF/jsp/manager/train/trains.jsp";
	public static final String MANAGER_ADD_TRAIN = "/WEB-INF/jsp/manager/train/add_train.jsp";
	public static final String MANAGER_EDIT_TRAIN = "/WEB-INF/jsp/manager/train/edit_train.jsp";

	public static final String MANAGER_COACHES = "/WEB-INF/jsp/manager/coach/coaches.jsp";
	public static final String MANAGER_ADD_COACH = "/WEB-INF/jsp/manager/coach/add_coach.jsp";
	public static final String MANAGER_EDIT_COACH = "/WEB-INF/jsp/manager/coach/edit_coach.jsp";

	public static final String MANAGER_COACHTYPES = "/WEB-INF/jsp/manager/coach/coachtypes.jsp";

	public static final String MANAGER_TRIPS = "/WEB-INF/jsp/manager/trip/trips.jsp";
	public static final String MANAGER_ADD_TRIP = "/WEB-INF/jsp/manager/trip/add_trip.jsp";
	public static final String MANAGER_EDIT_TRIP = "/WEB-INF/jsp/manager/trip/edit_trip.jsp";

	public static final String MANAGER_TICKETS = "/WEB-INF/jsp/manager/ticket/tickets.jsp";

	public static final String ADMIN_USERS = "/WEB-INF/jsp/manager/user/users.jsp";
	public static final String ADMIN_ADD_USER = "/WEB-INF/jsp/manager/user/add_user.jsp";
	public static final String ADMIN_EDIT_USER = "/WEB-INF/jsp/manager/user/edit_user.jsp";
	public static final String ADMIN_UNCONFIRMED_USERS = "/WEB-INF/jsp/manager/user/unconfirmed_users.jsp";

	public static final String ERROR_PAGE = "/WEB-INF/jsp/error_page.jsp";
	public static final String ERROR_404 = "/WEB-INF/jsp/error404_page.jsp";

}
