package ua.nure.bobrov.SummaryTask4.web.action.account;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.UnconfirmedUserDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.UserDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.UnconfirmedUser;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.util.FieldValidator;
import ua.nure.bobrov.SummaryTask4.util.MessageManager;
import ua.nure.bobrov.SummaryTask4.web.Message;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;
import ua.nure.bobrov.SummaryTask4.web.service.CaptchaVerifyService;
import ua.nure.bobrov.SummaryTask4.web.service.SendMailService;
/**
 * User registration action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class RegistrationAction extends Action {

	private static final Logger LOG = Logger.getLogger(RegistrationAction.class);
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {

		LOG.debug("Action starts");
		String email = request.getParameter(RequestProperty.EMAIL);
		String password = request.getParameter(RequestProperty.PASSWORD);
		String password2 = request.getParameter(RequestProperty.PASSWORD2);
		String name = request.getParameter(RequestProperty.NAME);
		String surname = request.getParameter(RequestProperty.SURNAME);
		String gRecaptchaResponse = request.getParameter(RequestProperty.CAPTCHA);

		LOG.trace("Request parameter email: " + email);
		LOG.trace("Request parameter password: " + password);
		LOG.trace("Request parameter password2: " + password2);
		LOG.trace("Request parameter name: " + name);
		LOG.trace("Request parameter surname: " + surname);
		LOG.trace("Request parameter gRecaptchaResponse: " + gRecaptchaResponse);
		
		if (!FieldValidator.isPasswordValid(password)) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_PASSWORD);
		} else if (!FieldValidator.isEmailValid(email) && email.length() <= 64) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_EMAIL);
		} else if (!FieldValidator.isNameFieldValid(name) || !FieldValidator.isNameFieldValid(surname)) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_NAME_SURNAME);
		} else if (!password.equals(password2)) {
			request.setAttribute(RequestProperty.ERROR, Message.PASSWORDS_NOT_MATCH);
		} else if (!CaptchaVerifyService.verifyCaptcha(gRecaptchaResponse)) {
			request.setAttribute(RequestProperty.ERROR, Message.WRONG_CAPTCHA);
		} else {
			UserDAO userDAO = new UserDAO();
			UnconfirmedUserDAO unconfirmedUserDAO = new UnconfirmedUserDAO();
			if (userDAO.getByEmail(email) != null || unconfirmedUserDAO.getByEmail(email) != null) {
				request.setAttribute(RequestProperty.ERROR, Message.USER_EXISTS);
			} else {

				UnconfirmedUser user = new UnconfirmedUser();
				String token = UUID.randomUUID().toString();
				user.setToken(token);
				user.setEmail(email);
				user.setPassword(password);
				user.setName(name);
				user.setSurname(surname);				
				String link = request.getServletContext().getInitParameter("context-URL")+ "controller/confirmation?token=" + token;
				StringBuilder message = new StringBuilder();
				message.append(MessageManager.getMessage(Message.CONFIRMATION_MESSAGE));
				message.append(" <a href=\"");
				message.append(link);
				message.append("\">");
				message.append(link);
				message.append("</a>");				
				if(SendMailService.sendMessage(email, MessageManager.getMessage(Message.CONFIRMATION_SUBJECT), message.toString())) {
					unconfirmedUserDAO.insert(user);
					LOG.debug("Action is completed successfully");
				} else {
					LOG.debug("Action is completed with error");
				}				
				return new PageData("confirmation_info", false);
			}
		}
		LOG.debug("Action is completed with error");
		return new PageData(Path.REGISTRATION_PAGE, true);
	}

}
