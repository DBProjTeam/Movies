package ua.nure.bobrov.SummaryTask4.web.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;

/**
 * View page action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class ViewPageAction extends Action{
	
	/**
	 * Path to the page to view
	 */
	private String path;
		
	public ViewPageAction(String path) {
		this.path = path;
	}
	
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		return new PageData(path, true);
	}

}
