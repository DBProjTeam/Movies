package ua.nure.bobrov.SummaryTask4.web.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ua.nure.bobrov.SummaryTask4.bean.CoachSeatsBean;
import ua.nure.bobrov.SummaryTask4.bean.TripSearchResultBean;
import ua.nure.bobrov.SummaryTask4.bean.TripSearchResultBean.SeatPriceBean;
import ua.nure.bobrov.SummaryTask4.database.dao.CoachDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.CoachTypeDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.RouteDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.TicketDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.TripDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.Coach;
import ua.nure.bobrov.SummaryTask4.database.entity.CoachType;
import ua.nure.bobrov.SummaryTask4.database.entity.Route;
import ua.nure.bobrov.SummaryTask4.database.entity.Ticket;
import ua.nure.bobrov.SummaryTask4.database.entity.Trip;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;

public class RouteStatisticAction extends Action{

	
	private Map<Integer, Integer> getCoachTypeMap(List<Coach> coachList) {
		Map<Integer, Integer> coachTypeMap = new TreeMap<Integer, Integer>();

		for (Coach coach : coachList) {
			coachTypeMap.put(coach.getType().getId(), 0);			
		}
		return coachTypeMap;
	}
	
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		RouteDAO routeDAO = new RouteDAO();
		TripDAO tripDAO = new TripDAO();
		CoachDAO coachDAO = new CoachDAO();
		TicketDAO ticketDAO = new TicketDAO();
		Map<Integer, List<SeatPriceBean>> statistics = new HashMap<Integer, List<SeatPriceBean>>();
		
		CoachTypeDAO coachTypeDAO = new CoachTypeDAO();
		Map<Integer, CoachType> coachTypeMap = coachTypeDAO.getAllInMap();
		
		List<Route> routeList = routeDAO.findAll();
		for(Route route : routeList) {
			List<Trip> tripList = tripDAO.findAllByRouteId(route.getId());
			Map<Integer, Integer> externalSeatsMap = new HashMap<Integer, Integer>(); // by (route coachId , number taken)
			List<SeatPriceBean> seatPriceBeans = new ArrayList<SeatPriceBean>();
			
			for(Trip trip : tripList) {
				List<Coach> coachList = coachDAO.findAllByTrainId(trip.getTrainId());
				List<Ticket> ticketList = ticketDAO.findAllByTriId(trip.getId());
				Map<Integer, Integer> freeSeatsMap = getCoachTypeMap(coachList); //by trip (route coachId , number taken)
				for(Ticket ticket : ticketList) {
					
					freeSeatsMap.put(ticket.getCoachTypeId(),
							freeSeatsMap.get(ticket.getCoachTypeId()) + 1);
					
				}
				Set<Entry<Integer, Integer>> entrySet = freeSeatsMap.entrySet();
				for (Entry<Integer, Integer> entry : entrySet) {
					if(externalSeatsMap.containsKey(entry.getKey())) {
						externalSeatsMap.put(entry.getKey(), externalSeatsMap.get(entry.getKey())+ entry.getValue());
					} else {
						externalSeatsMap.put(entry.getKey(), entry.getValue());
					}
					
				}				
			}
			
			
			Set<Entry<Integer, Integer>> entrySet = externalSeatsMap.entrySet();

			for (Entry<Integer, Integer> entry : entrySet) {
				SeatPriceBean seatPriceBean = new TripSearchResultBean.SeatPriceBean();
				seatPriceBean.setCoachType(coachTypeMap.get(entry.getKey()).getName());
				seatPriceBean.setFreeSeatsNumber(entry.getValue());
				seatPriceBeans.add(seatPriceBean);
			}
			statistics.put(route.getId(), seatPriceBeans);
		}
		
		Map<Integer, List<CoachSeatsBean>> map = routeDAO.getStatistics();
		Set<Entry<Integer, List<CoachSeatsBean>>> entryMap = map.entrySet();
		
		for(Entry<Integer, List<CoachSeatsBean>> entry : entryMap) {
			System.out.println(entry.getKey());
			for(CoachSeatsBean coachSeatsBean : entry.getValue()) {
				System.out.println("\t" + " " +coachTypeMap.get(coachSeatsBean.getCoachTypeId()).getName()+ " " + coachSeatsBean.getSeatNumber());
			}
		}
		request.setAttribute("result", statistics);
		return new PageData("/WEB-INF/jsp/statistics.jsp", true);
	}

}
