package ua.nure.bobrov.SummaryTask4.web.tag;

import java.io.IOException;
import java.util.Calendar;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.util.MessageManager;
import ua.nure.bobrov.SummaryTask4.web.Message;

/**
 * Footer tag. Displays current year, author and contact email
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class FooterTag extends TagSupport {

	private static final Logger LOG = Logger.getLogger(FooterTag.class);
	
	private static final long serialVersionUID = -7763781506205135314L;

	@Override
	public int doStartTag() throws JspException {
		String email = pageContext.getServletContext().getInitParameter("email");
		
		JspWriter writer = pageContext.getOut();
		try {
			writer.print(MessageManager.getMessage(Message.AUTHOR));
			writer.print(", ");
			writer.print(Calendar.getInstance().get(Calendar.YEAR));
			writer.print(". ");
			writer.print(MessageManager.getMessage(Message.CONTACT_US));
			writer.print(" <a href=mailto:'" + email + "'>" + email + "</a>");
		} catch (IOException e) {
			LOG.error(e.getMessage(), e);
		}
		return SKIP_BODY;
	}

}
