package ua.nure.bobrov.SummaryTask4.web.action.account;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.entity.User;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Log out action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class LogOutAction extends Action {

	private static final Logger LOG = Logger.getLogger(LogOutAction.class);

	@SuppressWarnings("unchecked")
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		LOG.debug("Action starts");
		HttpSession session = request.getSession();
		if (session != null) {
			Map<Integer, HttpSession> userMap = (Map<Integer, HttpSession>) request.getServletContext()
					.getAttribute(RequestProperty.USER_MAP);
			User user = (User) session.getAttribute(RequestProperty.USER);
			userMap.remove(user.getId());
			session.removeAttribute(RequestProperty.USER);
		}
		LOG.debug("Action is complited successfully");
		return new PageData("search_trip", false);
	}

}
