package ua.nure.bobrov.SummaryTask4.web.action.manager.routeitem;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.RouteItemDAO;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.util.FieldValidator;
import ua.nure.bobrov.SummaryTask4.web.Message;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Delete route item action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class DeleteRouteItemAction extends Action {

	private static final Logger LOG = Logger.getLogger(DeleteRouteItemAction.class);

	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		String routeItemIdString = request.getParameter("routeItemId");
		LOG.trace("Request parameter routeItemId: " + routeItemIdString);
		
		if (routeItemIdString == null || !FieldValidator.isPositiveInteger(routeItemIdString)) {
			request.setAttribute(RequestProperty.ERROR, Message.ROUTEITEM_NOT_EXISTS);
		} else {
			int routeId = Integer.parseInt(routeItemIdString);
			RouteItemDAO routeItemDAO = new RouteItemDAO();
			if (routeItemDAO.delete(routeId)) {
				LOG.debug("Action is completed successfully");
				return new PageData("routeitem_list", false);
			} else {
				request.setAttribute(RequestProperty.ERROR, Message.REMOVAL_IS_IMPOSSIBLE);
			}
		}
		LOG.debug("Action is completed with error");
		return new PageData(Path.ERROR_PAGE, true);
	}

}
