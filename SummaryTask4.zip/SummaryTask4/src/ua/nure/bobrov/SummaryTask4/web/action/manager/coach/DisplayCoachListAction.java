package ua.nure.bobrov.SummaryTask4.web.action.manager.coach;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.CoachDAO;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Display coach list action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class DisplayCoachListAction extends Action {

	private static final Logger LOG = Logger.getLogger(DisplayCoachListAction.class);
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		CoachDAO coachDAO = new CoachDAO();
		request.setAttribute(RequestProperty.COACHES, coachDAO.findAll());
		LOG.debug("Action is completed successfully");
		return new PageData(Path.MANAGER_COACHES, true);
	}

}
