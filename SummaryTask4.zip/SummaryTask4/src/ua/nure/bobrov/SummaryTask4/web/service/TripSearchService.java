package ua.nure.bobrov.SummaryTask4.web.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import ua.nure.bobrov.SummaryTask4.bean.TripDateTimeBean;
import ua.nure.bobrov.SummaryTask4.bean.TripDateTimeBean.TripTime;
import ua.nure.bobrov.SummaryTask4.database.entity.Route;
import ua.nure.bobrov.SummaryTask4.database.entity.RouteItem;

/**
 * Trip search service
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class TripSearchService {

	/**
	 * Return TripTime object
	 * 
	 * @param daysInTrip
	 *            days in trip
	 * @param timeBegin
	 *            trip begin time
	 * @param timeEnd
	 *            trip end time
	 * @return TripTime object
	 */
	private static TripTime getTripTime(int daysInTrip, Time timeBegin, Time timeEnd) {
		TripTime tripTime = new TripTime();
		long difference = 0;
		if (timeBegin.after(timeEnd)) {
			tripTime.setDays(daysInTrip - 1);
			difference = 24 * 60 * 60 * 1000 - timeBegin.getTime() + timeEnd.getTime();
		} else {
			tripTime.setDays(daysInTrip);
			difference = timeEnd.getTime() - timeBegin.getTime();
		}
		difference /= (1000 * 60);
		tripTime.setHours((int) difference / (60));
		difference -= tripTime.getHours() * 60;
		tripTime.setMinutes((int) difference);
		return tripTime;
	}

	/**
	 * Calculates ticket price based on coach type payment coefficient and time
	 * of the trip
	 * 
	 * @param time
	 *            trip time
	 * @param coefficient
	 *            coach type payment coefficient
	 * @return ticket price
	 */
	public static double getPrice(TripTime time, double coefficient) {
		return new BigDecimal(
				(time.getMinutes() + time.getHours() * 60 + time.getDays() * 60 * 24) * 0.15 * coefficient)
						.setScale(2, RoundingMode.HALF_UP).doubleValue();
	}
	/**
	 * Returns TripDateTimeBean object. Method checks if departureStation and
	 * arrivalStation are in route and if so calculates departure date, arrival
	 * date an time in trip
	 * 
	 * @param routeItems
	 *            route items in route
	 * @param route
	 * @param departureStationId
	 * @param arrivalStationId
	 * @param departureDate
	 * @return TripDateTimeBean object
	 */
	public static TripDateTimeBean getTripDateTimeBean(List<RouteItem> routeItems, Route route, int departureStationId,
			int arrivalStationId, Date departureDate) {

		TripDateTimeBean tripBean = null;

		Time previousTime = route.getBeginTime();
		Time departureTime = route.getBeginTime();
		Time arrivalTime = route.getEndTime();
		boolean isAfterDeparture = false;
		boolean isStationFound = false;

		int daysBeforeTrip = 0;
		int daysInTrip = 0;

		if (route.getBeginStation().getId() == departureStationId) {
			isAfterDeparture = true;
		}
		for (RouteItem routeItem : routeItems) {
			if (isAfterDeparture) {
				if (previousTime.after(routeItem.getArrivalTime())) {
					daysInTrip++;
				}
				if (routeItem.getStationId() == arrivalStationId) {
					isStationFound = true;
					arrivalTime = routeItem.getArrivalTime();
					break;
				}
				if (routeItem.getArrivalTime().after(routeItem.getDepartureTime())) {
					daysInTrip++;
				}
			} else {
				if (previousTime.after(routeItem.getArrivalTime())
						|| routeItem.getArrivalTime().after(routeItem.getDepartureTime())) {
					daysBeforeTrip++;
				}
			}
			if (routeItem.getStationId() == departureStationId) {
				departureTime = routeItem.getDepartureTime();
				isAfterDeparture = true;
			}
			previousTime = routeItem.getDepartureTime();
		}
		if (!isStationFound && isAfterDeparture && route.getEndStation().getId() == arrivalStationId) {
			if (previousTime.after(route.getEndTime())) {
				daysInTrip++;
			}
			isStationFound = true;
		}
		if (isStationFound) {
			tripBean = new TripDateTimeBean();

			Calendar calendarDate = new GregorianCalendar();
			Calendar calendarTime = new GregorianCalendar();
			calendarDate.setTime(departureDate);
			calendarTime.setTime(departureTime);
			calendarDate.add(Calendar.DAY_OF_YEAR, daysBeforeTrip);
			calendarDate.add(Calendar.HOUR_OF_DAY, calendarTime.get(Calendar.HOUR_OF_DAY));
			calendarDate.add(Calendar.MINUTE, calendarTime.get(Calendar.MINUTE));
			Timestamp date = new Timestamp(calendarDate.getTimeInMillis());
			tripBean.setDepartureDate(date);

			calendarDate.setTime(departureDate);
			calendarTime.setTime(arrivalTime);
			calendarDate.add(Calendar.DAY_OF_YEAR, daysBeforeTrip);
			calendarDate.add(Calendar.DAY_OF_YEAR, daysInTrip);
			calendarDate.add(Calendar.HOUR_OF_DAY, calendarTime.get(Calendar.HOUR_OF_DAY));
			calendarDate.add(Calendar.MINUTE, calendarTime.get(Calendar.MINUTE));
			date = new Timestamp(calendarDate.getTimeInMillis());
			tripBean.setArrivalDate(date);
			TripTime tripTime = getTripTime(daysInTrip, departureTime, arrivalTime);
			tripBean.setTripTime(tripTime);
		}
		return tripBean;
	}

}
