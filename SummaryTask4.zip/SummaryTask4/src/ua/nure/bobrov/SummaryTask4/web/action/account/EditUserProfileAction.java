package ua.nure.bobrov.SummaryTask4.web.action.account;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.UserDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.User;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.util.FieldValidator;
import ua.nure.bobrov.SummaryTask4.web.Message;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Edit user profile action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class EditUserProfileAction extends Action{

	private static final Logger LOG = Logger.getLogger(EditUserProfileAction.class);
	
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		String name = request.getParameter(RequestProperty.NAME);
		String surname = request.getParameter(RequestProperty.SURNAME);

		LOG.trace("Request parameter name: " + name);
		LOG.trace("Request parameter surname: " + surname);
		
		if (!FieldValidator.isNameFieldValid(name) || !FieldValidator.isNameFieldValid(surname)) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_NAME_SURNAME);
		} else {
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute(RequestProperty.USER);
			user.setName(name);
			user.setSurname(surname);
			UserDAO userDAO = new UserDAO();
			userDAO.update(user);
			LOG.debug("Action is completed successfully");
			return new PageData("user_profile", false);			
		}
		LOG.debug("Action is completed with error");
		return new PageData(Path.USER_PROFILE, true);		
	}

}
