package ua.nure.bobrov.SummaryTask4.web.action.account;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.UnconfirmedUserDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.UserDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.UnconfirmedUser;
import ua.nure.bobrov.SummaryTask4.database.entity.User;
import ua.nure.bobrov.SummaryTask4.enums.RoleType;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.web.Message;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Registration confirmation action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class ConfirmationAction extends Action {

	private static final Logger LOG = Logger.getLogger(ConfirmationAction.class);
	
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		String token = request.getParameter(RequestProperty.TOKEN);
		
		LOG.trace("Request parameter token: " + token);
		
		if (token != null) {
			
			UnconfirmedUserDAO unconfirmedUserDAO = new UnconfirmedUserDAO();
			UnconfirmedUser unconfirmedUser = unconfirmedUserDAO.getByToken(token);
			if(unconfirmedUser != null) {
				
				UserDAO userDAO = new UserDAO();
				User user = new User();
				user.setEmail(unconfirmedUser.getEmail());
				user.setPassword(unconfirmedUser.getPassword());
				user.setName(unconfirmedUser.getName());
				user.setSurname(unconfirmedUser.getSurname());
				user.setRole(RoleType.CLIENT);
				user.setBanned(false);
				userDAO.insert(user);	
				LOG.debug("Action is completed successfully");
				return new PageData("login", false);
			}
		}
		request.setAttribute(RequestProperty.ERROR, Message.CONFIRMATION_NOT_AVALIABLE);
		LOG.debug("Action is completed with error");
		return new PageData(Path.ERROR_PAGE, true);
	}

}
