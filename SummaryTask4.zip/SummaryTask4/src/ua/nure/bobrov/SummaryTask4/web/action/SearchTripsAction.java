package ua.nure.bobrov.SummaryTask4.web.action;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.bean.TripDateTimeBean;
import ua.nure.bobrov.SummaryTask4.bean.TripSearchResultBean;
import ua.nure.bobrov.SummaryTask4.bean.TripSearchResultBean.SeatPriceBean;
import ua.nure.bobrov.SummaryTask4.database.dao.CoachDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.CoachTypeDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.RouteDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.RouteItemDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.StationDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.TicketDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.TrainDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.TripDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.Coach;
import ua.nure.bobrov.SummaryTask4.database.entity.CoachType;
import ua.nure.bobrov.SummaryTask4.database.entity.Route;
import ua.nure.bobrov.SummaryTask4.database.entity.RouteItem;
import ua.nure.bobrov.SummaryTask4.database.entity.Station;
import ua.nure.bobrov.SummaryTask4.database.entity.Ticket;
import ua.nure.bobrov.SummaryTask4.database.entity.Train;
import ua.nure.bobrov.SummaryTask4.database.entity.Trip;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.util.DateParser;
import ua.nure.bobrov.SummaryTask4.util.FieldValidator;
import ua.nure.bobrov.SummaryTask4.web.Message;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.service.TripSearchService;

/**
 * Search trips action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class SearchTripsAction extends Action {

	private static final Logger LOG = Logger.getLogger(SearchTripsAction.class);

	/**
	 * Checks if parameter calendar1 and calendar2 refers to the same day
	 * 
	 * @param calendar1
	 * @param calendar2
	 * @return true if parameter calendar1 and calendar2 refers to the same day,
	 *         false otherwise
	 */
	private static boolean isTheSameDay(Calendar calendar1, Calendar calendar2) {
		return (calendar1.get(Calendar.ERA) == calendar2.get(Calendar.ERA)
				&& calendar1.get(Calendar.YEAR) == calendar2.get(Calendar.YEAR)
				&& calendar1.get(Calendar.DAY_OF_YEAR) == calendar2.get(Calendar.DAY_OF_YEAR));
	}

	/**
	 * Returns map of coach type ids as keys and coach's passenger number as
	 * value
	 * 
	 * @param coachList
	 * @return
	 */
	private Map<Integer, Integer> getCoachTypeMap(List<Coach> coachList) {
		Map<Integer, Integer> coachTypeMap = new TreeMap<Integer, Integer>();

		for (Coach coach : coachList) {
			if (coachTypeMap.containsKey(coach.getType().getId())) {
				coachTypeMap.put(coach.getType().getId(),
						coach.getType().getMaxPassengerNumber() + coachTypeMap.get(coach.getType().getId()));
			} else {
				coachTypeMap.put(coach.getType().getId(), coach.getType().getMaxPassengerNumber());
			}
		}
		return coachTypeMap;
	}

	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");

		String dateParameter = request.getParameter(RequestProperty.DEPARTURE_DATE);
		String fromParameter = request.getParameter(RequestProperty.FROM);
		String toParameter = request.getParameter(RequestProperty.TO);

		LOG.trace("Request parameter dateParameter: " + dateParameter);
		LOG.trace("Request parameter fromParameter: " + fromParameter);
		LOG.trace("Request parameter toParameter: " + toParameter);

		if (!FieldValidator.isTextFieldValid(fromParameter, 45) || !FieldValidator.isTextFieldValid(toParameter, 45)) {
			request.setAttribute(RequestProperty.ERROR, Message.STATION_NOT_SPECIFIED);
		} else {
			Date departureDate = DateParser.parseDate(dateParameter);
			if (departureDate == null) {
				request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_DATE);
			} else if (departureDate.before(Calendar.getInstance().getTime())) {
				request.setAttribute(RequestProperty.ERROR, Message.DATE_BEFORE_TODAY);
			} else {

				StationDAO stationDAO = new StationDAO();
				Station departureStation = stationDAO.getByName(fromParameter);
				Station arrivalStation = stationDAO.getByName(toParameter);

				if ((departureStation == null) || (arrivalStation == null)) {
					request.setAttribute(RequestProperty.ERROR, Message.STATION_NOT_FOUND);
				} else {
					TripDAO tripDAO = new TripDAO();
					List<Trip> tripList = tripDAO.findAllByDepartureDate(departureDate);

					RouteDAO routeDAO = new RouteDAO();
					RouteItemDAO routeItemDAO = new RouteItemDAO();
					TicketDAO ticketDAO = new TicketDAO();
					TrainDAO trainDAO = new TrainDAO();
					CoachDAO coachDAO = new CoachDAO();
					List<TripSearchResultBean> searchResultBeans = new ArrayList<TripSearchResultBean>();

					for (Trip trip : tripList) {
						List<RouteItem> routeItems = routeItemDAO.findAllByRouteId(trip.getRouteId());
						Route route = routeDAO.getByPK(trip.getRouteId());

						List<Coach> coachList = coachDAO.findAllByTrainId(trip.getTrainId());
						Train train = trainDAO.getByPK(trip.getTrainId());

						TripDateTimeBean time = TripSearchService.getTripDateTimeBean(routeItems, route,
								departureStation.getId(), arrivalStation.getId(), trip.getDepartureDate());

						if (time != null) {
							Calendar departureDateFound = new GregorianCalendar();
							departureDateFound.setTime(time.getDepartureDate());
							Calendar departureDateParam = new GregorianCalendar();
							departureDateParam.setTime(departureDate);
							if (isTheSameDay(departureDateFound, departureDateParam)) {
								TripSearchResultBean searchResult = new TripSearchResultBean();

								searchResult.setTrainNumber(train.getNumber());
								searchResult.setDepartureStation(departureStation);
								searchResult.setArrivalStation(arrivalStation);
								searchResult.setTripId(trip.getId());
								searchResult.setTime(time);

								List<SeatPriceBean> seatPriceBeans = new ArrayList<SeatPriceBean>();
								List<Ticket> ticketList = ticketDAO.findAllByDateRange(trip.getId(),
										time.getDepartureDate(), time.getArrivalDate());
								Map<Integer, Integer> freeSeatsMap = getCoachTypeMap(coachList);
								for (Ticket ticket : ticketList) {
									freeSeatsMap.put(ticket.getCoachTypeId(),
											freeSeatsMap.get(ticket.getCoachTypeId()) - 1);
								}
								CoachTypeDAO coachTypeDAO = new CoachTypeDAO();
								Map<Integer, CoachType> coachTypeMap = coachTypeDAO.getAllInMap();
								Set<Entry<Integer, Integer>> entrySet = freeSeatsMap.entrySet();

								for (Entry<Integer, Integer> entry : entrySet) {
									SeatPriceBean seatPriceBean = new TripSearchResultBean.SeatPriceBean();
									seatPriceBean.setCoachType(coachTypeMap.get(entry.getKey()).getName());
									seatPriceBean.setFreeSeatsNumber(entry.getValue());
									seatPriceBean.setPrice((TripSearchService.getPrice(time.getTripTime(),
											coachTypeMap.get(entry.getKey()).getCoefficient())));
									seatPriceBeans.add(seatPriceBean);
								}
								if (!seatPriceBeans.isEmpty()) {
									searchResult.setSeatPriceBeans(seatPriceBeans);
									searchResultBeans.add(searchResult);
								}
							}
						}
					}
					request.setAttribute(RequestProperty.SEARCH_RESULTS, searchResultBeans);
					LOG.debug("Action is completed successfully");
					return new PageData(Path.TRIP_LIST, true);
				}
			}
		}
		LOG.debug("Action is completed with error");
		return new PageData(Path.SEARCH_TRIP, true);
	}
}
