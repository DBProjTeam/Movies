package ua.nure.bobrov.SummaryTask4.web.action.manager.coach;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.CoachTypeDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.CoachType;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Display coach type list action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class DisplayCoachTypeListAction extends Action {

	private static final Logger LOG = Logger.getLogger(DisplayCoachTypeListAction.class);
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		CoachTypeDAO coachTypeDAO = new CoachTypeDAO();
		request.setAttribute(RequestProperty.COACHTYPES, new ArrayList<CoachType>(coachTypeDAO.getAllInMap().values()));
		LOG.debug("Action is completed successfully");
		return new PageData(Path.MANAGER_COACHTYPES, true);
	}

}
