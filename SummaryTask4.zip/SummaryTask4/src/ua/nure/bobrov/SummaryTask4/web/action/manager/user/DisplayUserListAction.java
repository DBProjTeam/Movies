package ua.nure.bobrov.SummaryTask4.web.action.manager.user;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.UserDAO;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.Action;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

/**
 * Display user list action
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class DisplayUserListAction extends Action{

	private static final Logger LOG = Logger.getLogger(DisplayUserListAction.class);
	@Override
	public PageData execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException, DatabaseException {
		LOG.debug("Action starts");
		UserDAO userDAO = new UserDAO();
		request.setAttribute(RequestProperty.USERS, userDAO.findAll());
		LOG.debug("Action is completed successfully");
		return new PageData(Path.ADMIN_USERS, true);
	}

}
