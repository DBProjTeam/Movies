package ua.nure.bobrov.SummaryTask4.exception;

/**
 * An exception that provides information on a database access error.
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class DatabaseException extends Exception {

	private static final long serialVersionUID = 8486886523003078504L;

	public DatabaseException() {
		super();
	}

	public DatabaseException(String message, Throwable cause) {
		super(message, cause);
	}

}
