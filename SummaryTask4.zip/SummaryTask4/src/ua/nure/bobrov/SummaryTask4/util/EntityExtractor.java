package ua.nure.bobrov.SummaryTask4.util;

import java.sql.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import ua.nure.bobrov.SummaryTask4.database.dao.RouteDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.StationDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.TrainDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.Route;
import ua.nure.bobrov.SummaryTask4.database.entity.RouteItem;
import ua.nure.bobrov.SummaryTask4.database.entity.Station;
import ua.nure.bobrov.SummaryTask4.database.entity.Trip;
import ua.nure.bobrov.SummaryTask4.database.entity.User;
import ua.nure.bobrov.SummaryTask4.enums.RoleType;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.web.Message;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;

/**
 * Util class for extracting objects from http servlet request
 * 
 * @author Bobrov Vyacheslav
 */
public class EntityExtractor {

	private static final Logger LOG = Logger.getLogger(EntityExtractor.class);

	/**
	 * Extracts Station object from request
	 * 
	 * @param request
	 * @param stationDAO
	 * @return
	 * @throws DatabaseException
	 */
	public static Station extractStation(HttpServletRequest request, StationDAO stationDAO) throws DatabaseException {
		String stationName = request.getParameter(RequestProperty.NAME);
		LOG.trace("Request parameter name: " + stationName);
		Station station = null;
		if (!FieldValidator.isTextFieldValid(stationName, 45)) {
			request.setAttribute(RequestProperty.ERROR, Message.WRONG_STATION_NAME);
		} else {
			if (stationDAO.getByName(stationName) != null) {
				request.setAttribute(RequestProperty.ERROR, Message.STATION_EXISTS);
			} else {
				station = new Station();
				station.setName(stationName);
			}
		}
		return station;
	}

	/**
	 * Extracts Route object from request
	 * 
	 * @param request
	 * @param stationDAO
	 * @return
	 * @throws DatabaseException
	 */
	public static Route extractRoute(HttpServletRequest request, StationDAO stationDAO) throws DatabaseException {

		Route route = null;
		String beginStationIdString = request.getParameter(RequestProperty.BEGIN_STATION_ID);
		String endStationIdString = request.getParameter(RequestProperty.END_STATION_ID);
		String departureTimeString = request.getParameter(RequestProperty.DEPARTURE_TIME);
		String arrivalTimeString = request.getParameter(RequestProperty.ARRIVAL_TIME);

		LOG.trace("Request parameter beginStationId: " + beginStationIdString);
		LOG.trace("Request parameter endStationId: " + endStationIdString);
		LOG.trace("Request parameter departureTime: " + departureTimeString);
		LOG.trace("Request parameter arrivalTime: " + arrivalTimeString);

		if (!FieldValidator.isPositiveInteger(beginStationIdString)
				|| !FieldValidator.isPositiveInteger(endStationIdString)) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_STATION_ID);
		} else if (!FieldValidator.isTimeValid(departureTimeString) || !FieldValidator.isTimeValid(arrivalTimeString)) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_TIME);
		} else {
			int beginStationId = Integer.parseInt(beginStationIdString);
			int endStationId = Integer.parseInt(endStationIdString);
			Station beginStation = null;
			Station endStation = null;
			if (beginStationId == endStationId) {
				request.setAttribute(RequestProperty.ERROR, Message.STATIONS_EQUAL);
			} else if ((beginStation = stationDAO.getByPK(beginStationId)) == null
					|| (endStation = stationDAO.getByPK(endStationId)) == null) {
				request.setAttribute(RequestProperty.ERROR, Message.STATION_NOT_EXISTS);
			} else {
				route = new Route();
				route.setBeginStation(beginStation);
				route.setEndStation(endStation);
				route.setBeginTime(DateParser.parseTime(departureTimeString));
				route.setEndTime(DateParser.parseTime(arrivalTimeString));
			}
		}
		return route;
	}

	/**
	 * Extracts RouteItem object from request
	 * 
	 * @param request
	 * @param stationDAO
	 * @param routeDAO
	 * @return
	 * @throws DatabaseException
	 */
	public static RouteItem extractRouteItem(HttpServletRequest request, StationDAO stationDAO, RouteDAO routeDAO)
			throws DatabaseException {

		RouteItem routeItem = null;
		String routeIdString = request.getParameter(RequestProperty.ROUTE_ID);
		String stationIdString = request.getParameter(RequestProperty.STATION_ID);
		String arrivalTimeString = request.getParameter(RequestProperty.ARRIVAL_TIME);
		String departureTimeString = request.getParameter(RequestProperty.DEPARTURE_TIME);
		String sequenceNumberString = request.getParameter(RequestProperty.SEQUENCE_NUMBER);

		LOG.trace("Request parameter routeId: " + routeIdString);
		LOG.trace("Request parameter stationId: " + stationIdString);
		LOG.trace("Request parameter arrivalTime: " + arrivalTimeString);
		LOG.trace("Request parameter departureTime: " + departureTimeString);
		LOG.trace("Request parameter sequenceNumber: " + sequenceNumberString);

		if (!FieldValidator.isPositiveInteger(routeIdString)) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_ROUTE_ID);
		} else if (!FieldValidator.isPositiveInteger(stationIdString)) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_STATION_ID);
		} else if (!FieldValidator.isTimeValid(arrivalTimeString) || !FieldValidator.isTimeValid(departureTimeString)) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_TIME);
		} else if (!FieldValidator.isPositiveInteger(sequenceNumberString)) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_NUMBER);
		} else {

			int routeId = Integer.parseInt(routeIdString);
			int stationId = Integer.parseInt(stationIdString);
			int sequenceNumber = Integer.parseInt(sequenceNumberString);
			Route route = null;
			Station station = null;
			if ((route = routeDAO.getByPK(routeId)) == null) {
				request.setAttribute(RequestProperty.ERROR, Message.ROUTE_NOT_EXISTS);
			} else if ((station = stationDAO.getByPK(stationId)) == null) {
				request.setAttribute(RequestProperty.ERROR, Message.STATION_NOT_EXISTS);
			} else if (station.getId() == route.getBeginStation().getId()
					|| station.getId() == route.getEndStation().getId()) {
				request.setAttribute(RequestProperty.ERROR, Message.STATION_IN_ROUTE);
			} else if (sequenceNumber < 1) {
				request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_NUMBER);
			} else {
				routeItem = new RouteItem();
				routeItem.setRouteId(routeId);
				routeItem.setStationId(stationId);
				routeItem.setArrivalTime(DateParser.parseTime(arrivalTimeString));
				routeItem.setDepartureTime(DateParser.parseTime(departureTimeString));
				routeItem.setSequenceNumber(sequenceNumber);
			}
		}
		return routeItem;
	}

	/**
	 * Extracts Trip object from request
	 * 
	 * @param request
	 * @param trainDAO
	 * @param routeDAO
	 * @return
	 * @throws DatabaseException
	 */
	public static Trip extractTrip(HttpServletRequest request, TrainDAO trainDAO, RouteDAO routeDAO)
			throws DatabaseException {

		Trip trip = null;
		String routeIdString = request.getParameter(RequestProperty.ROUTE_ID);
		String trainIdString = request.getParameter(RequestProperty.TRAIN_ID);
		String departureDateString = request.getParameter(RequestProperty.DEPARTURE_DATE);

		LOG.trace("Request parameter routeId: " + routeIdString);
		LOG.trace("Request parameter trainId: " + trainIdString);
		LOG.trace("Request parameter departureDate: " + departureDateString);

		Date departureDate = null;

		if (!FieldValidator.isPositiveInteger(routeIdString)) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_ROUTE_ID);
		} else if (!FieldValidator.isPositiveInteger(trainIdString)) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_TRAIN_ID);
		} else if (!FieldValidator.isDateValid(departureDateString)
				|| (departureDate = DateParser.parseDate(departureDateString)) == null) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_DATE);
		} else {

			int routeId = Integer.parseInt(routeIdString);
			int trainId = Integer.parseInt(trainIdString);

			if (trainDAO.getByPK(trainId) == null) {
				request.setAttribute(RequestProperty.ERROR, Message.TRAIN_NOT_EXISTS);
			} else if (routeDAO.getByPK(routeId) == null) {
				request.setAttribute(RequestProperty.ERROR, Message.ROUTE_NOT_EXISTS);
			} else {
				trip = new Trip();
				trip.setRouteId(routeId);
				trip.setTrainId(trainId);
				trip.setDepartureDate(departureDate);

			}
		}
		return trip;
	}

	/**
	 * Extracts User object from request
	 * 
	 * @param request
	 * @return
	 * @throws DatabaseException
	 */
	public static User extractUser(HttpServletRequest request) throws DatabaseException {

		User user = null;
		String email = request.getParameter(RequestProperty.EMAIL);
		String password = request.getParameter(RequestProperty.PASSWORD);
		String name = request.getParameter(RequestProperty.NAME);
		String surname = request.getParameter(RequestProperty.SURNAME);
		String roleId = request.getParameter(RequestProperty.ROLE_ID);
		
		LOG.trace("Request parameter email: " + email);
		LOG.trace("Request parameter password: " + password);
		LOG.trace("Request parameter name: " + name);
		LOG.trace("Request parameter surname: " + surname);
		LOG.trace("Request parameter roleId: " + roleId);

		if (!FieldValidator.isEmailValid(email)) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_EMAIL);
		} else if (!FieldValidator.isPasswordValid(password)) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_PASSWORD);
		} else if (!FieldValidator.isNameFieldValid(name) || !FieldValidator.isNameFieldValid(surname)) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_NAME_SURNAME);
		} else if (!FieldValidator.isPositiveInteger(roleId)) {
			request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_ROLE);
		} else {
			RoleType roleType = null;

			if ((roleType = RoleType.getRoleType(Integer.parseInt(roleId))) == null
					|| roleType.equals(RoleType.ADMIN)) {
				request.setAttribute(RequestProperty.ERROR, Message.NOT_VALID_ROLE);
			} else {
				user = new User();
				user.setEmail(email);
				user.setPassword(password);
				user.setName(name);
				user.setSurname(surname);
				user.setRole(roleType);
				user.setBanned(false);
			}
		}
		return user;
	}

}
