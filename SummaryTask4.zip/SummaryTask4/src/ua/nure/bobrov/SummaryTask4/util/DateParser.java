package ua.nure.bobrov.SummaryTask4.util;

import java.sql.Date;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;

/**
 * Util class for parsing Date and Time
 * 
 * @author Bobrov Vyacheslav
 *
 */
public class DateParser {

	private static final Logger LOG = Logger.getLogger(DateParser.class);

	/**
	 * Returns parsed date
	 * 
	 * @param dateString
	 *            date to parse
	 * @return
	 */
	public static Date parseDate(String dateString) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
		Date parsedDate = null;
		try {
			parsedDate = new Date(dateFormat.parse(dateString).getTime());
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			return null;
		}
		return parsedDate;
	}

	/**
	 * Return parsed time
	 * 
	 * @param timeString
	 *            time to parse
	 * @return
	 */
	public static Time parseTime(String timeString) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
		Date parsedTime = null;
		try {
			parsedTime = new Date(dateFormat.parse(timeString).getTime());
		} catch (ParseException e) {
			LOG.error(e.getMessage(), e);
			return null;
		}
		return new Time(parsedTime.getTime());
	}

}
