package ua.nure.bobrov.SummaryTask4.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class FieldValidatorTest {

	@Test
	public void testIsPasswordValid() {
		assertTrue(FieldValidator.isPasswordValid("password8"));
	}
	@Test
	public void testIsPasswordValid2() {
		assertFalse(FieldValidator.isPasswordValid("������"));
	}
	@Test
	public void testIsEmailValid() {
		assertTrue(FieldValidator.isEmailValid("admin@gmail.com"));
	}
	@Test
	public void testIsEmailValid2() {
		assertFalse(FieldValidator.isEmailValid("email"));
	}
	@Test
	public void testIsPositiveInteger() {
		assertTrue(FieldValidator.isPositiveInteger("885"));
	}
	@Test
	public void testIsPositiveInteger2() {
		assertFalse(FieldValidator.isPositiveInteger("string"));
	}
	@Test
	public void testIsTimeValid() {
		assertTrue(FieldValidator.isTimeValid("5:00"));
	}
	@Test
	public void testIsTimeValid2() {
		assertFalse(FieldValidator.isTimeValid("times"));
	}
	@Test
	public void testIsTestFieldValid() {
		assertTrue(FieldValidator.isTextFieldValid("text", 5));
	}
	@Test
	public void testIsTestFieldValid2() {
		assertFalse(FieldValidator.isTextFieldValid("times",1));
	}
}
