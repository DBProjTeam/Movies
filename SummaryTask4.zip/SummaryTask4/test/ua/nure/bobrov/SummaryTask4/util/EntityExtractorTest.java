package ua.nure.bobrov.SummaryTask4.util;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;

import org.junit.Test;

import ua.nure.bobrov.SummaryTask4.database.dao.RouteDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.StationDAO;
import ua.nure.bobrov.SummaryTask4.database.dao.TrainDAO;
import ua.nure.bobrov.SummaryTask4.database.entity.Route;
import ua.nure.bobrov.SummaryTask4.database.entity.Station;
import ua.nure.bobrov.SummaryTask4.database.entity.Train;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;

public class EntityExtractorTest {

	@Test
	public void testExtractStation() throws DatabaseException {
		String stationName = "Kharkiv";
		StationDAO stationDAO = mock(StationDAO.class);
		HttpServletRequest request = mock(HttpServletRequest.class);
		when(request.getParameter(RequestProperty.NAME)).thenReturn(stationName);
		when(stationDAO.getByName(stationName)).thenReturn(null);
		
		Station actualStation = EntityExtractor.extractStation(request, stationDAO);
		assertTrue(actualStation.getName().equals(stationName));		
	}
	
	@Test
	public void testExtractRoute() throws DatabaseException {
		HttpServletRequest request = mock(HttpServletRequest.class);
		when(request.getParameter(RequestProperty.BEGIN_STATION_ID)).thenReturn("1");
		when(request.getParameter(RequestProperty.END_STATION_ID)).thenReturn("2");
		when(request.getParameter(RequestProperty.DEPARTURE_TIME)).thenReturn("5:00");
		when(request.getParameter(RequestProperty.ARRIVAL_TIME)).thenReturn("8:00");
		StationDAO stationDAO = mock(StationDAO.class);
		Station beginStation = new Station();
		Station endStation = new Station();
		when(stationDAO.getByPK(1)).thenReturn(beginStation);
		when(stationDAO.getByPK(2)).thenReturn(endStation);
		assertTrue(EntityExtractor.extractRoute(request, stationDAO) != null);
	}

	@Test
	public void testExtractRouteItem() throws DatabaseException {
		HttpServletRequest request = mock(HttpServletRequest.class);
		when(request.getParameter(RequestProperty.ROUTE_ID)).thenReturn("1");
		when(request.getParameter(RequestProperty.STATION_ID)).thenReturn("2");		
		when(request.getParameter(RequestProperty.ARRIVAL_TIME)).thenReturn("8:00");
		when(request.getParameter(RequestProperty.DEPARTURE_TIME)).thenReturn("8:10");
		when(request.getParameter(RequestProperty.SEQUENCE_NUMBER)).thenReturn("1");
		StationDAO stationDAO = mock(StationDAO.class);
		RouteDAO routeDAO = mock(RouteDAO.class);
		Route route = new Route();
		Station beginStation = new Station();
		beginStation.setId(5);
		Station endStation = new Station();
		endStation.setId(8);
		route.setBeginStation(beginStation);
		route.setEndStation(endStation);
		Station returnedStation = new Station();
		returnedStation.setId(2);
		route.setBeginStation(beginStation);
		route.setEndStation(endStation);
		when(routeDAO.getByPK(1)).thenReturn(route);
		when(stationDAO.getByPK(2)).thenReturn(returnedStation);
		assertTrue(EntityExtractor.extractRouteItem(request, stationDAO, routeDAO) != null);
	}
	
	@Test
	public void testExtractTrip() throws DatabaseException {
		HttpServletRequest request = mock(HttpServletRequest.class);
		when(request.getParameter(RequestProperty.ROUTE_ID)).thenReturn("1");
		when(request.getParameter(RequestProperty.TRAIN_ID)).thenReturn("5");	
		when(request.getParameter(RequestProperty.DEPARTURE_DATE)).thenReturn("20.02.2016");
		TrainDAO trainDAO = mock(TrainDAO.class);
		RouteDAO routeDAO = mock(RouteDAO.class);
		when(trainDAO.getByPK(5)).thenReturn(new Train());
		when(routeDAO.getByPK(1)).thenReturn(new Route());
		assertTrue(EntityExtractor.extractTrip(request, trainDAO, routeDAO) != null);
	}
	
	@Test
	public void testExtractUser() throws DatabaseException {
		HttpServletRequest request = mock(HttpServletRequest.class);
		when(request.getParameter(RequestProperty.EMAIL)).thenReturn("admin@gmail.com");
		when(request.getParameter(RequestProperty.PASSWORD)).thenReturn("1554858");	
		when(request.getParameter(RequestProperty.NAME)).thenReturn("Name");
		when(request.getParameter(RequestProperty.SURNAME)).thenReturn("Surname");
		when(request.getParameter(RequestProperty.ROLE_ID)).thenReturn("1");
		assertTrue(EntityExtractor.extractUser(request) != null);
		
	}
}
