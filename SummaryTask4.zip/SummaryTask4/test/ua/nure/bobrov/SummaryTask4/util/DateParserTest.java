package ua.nure.bobrov.SummaryTask4.util;

import static org.junit.Assert.assertTrue;

import java.sql.Date;
import java.sql.Time;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.junit.Test;

public class DateParserTest {

	@Test
	public void testParseDate() {
		String dateString = "18.02.2016";
		Calendar calendar = new GregorianCalendar(2016, 1, 18);
		Date expectedDate = new Date(calendar.getTimeInMillis());
		Date actualDate = DateParser.parseDate(dateString);
		assertTrue(expectedDate.equals(actualDate));
	}
	@Test
	public void testParseDate2() {
		String dateString = "some date";
		Date actualDate = DateParser.parseDate(dateString);
		assertTrue(actualDate == null);
	}
	@Test
	public void testParseTime() {
		String timeString = "5:00";
		Calendar calendar = new GregorianCalendar(1970, 0, 1,5,0);
		Time expectedTime = new Time(calendar.getTimeInMillis());
		Time actualTime = DateParser.parseTime(timeString);
		assertTrue(expectedTime.equals(actualTime));
	}
	@Test
	public void testParseTime2() {
		String timeString = "some time";
		Time actualTime = DateParser.parseTime(timeString);
		assertTrue(actualTime == null);
	}

}
