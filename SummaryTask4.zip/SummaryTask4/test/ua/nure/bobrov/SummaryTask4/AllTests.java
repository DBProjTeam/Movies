package ua.nure.bobrov.SummaryTask4;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import ua.nure.bobrov.SummaryTask4.bean.TripSearchResultBeanTest;
import ua.nure.bobrov.SummaryTask4.database.dao.CoachDAOTest;
import ua.nure.bobrov.SummaryTask4.database.dao.CoachTypeDAOTest;
import ua.nure.bobrov.SummaryTask4.database.dao.RouteDAOTest;
import ua.nure.bobrov.SummaryTask4.database.dao.RouteItemDAOTest;
import ua.nure.bobrov.SummaryTask4.database.dao.StationDAOTest;
import ua.nure.bobrov.SummaryTask4.database.dao.TicketDAOTest;
import ua.nure.bobrov.SummaryTask4.database.dao.TrainDAOTest;
import ua.nure.bobrov.SummaryTask4.database.dao.TripDAOTest;
import ua.nure.bobrov.SummaryTask4.database.dao.UnconfirmedUserDAOTest;
import ua.nure.bobrov.SummaryTask4.database.dao.UserDAOTest;
import ua.nure.bobrov.SummaryTask4.util.DateParserTest;
import ua.nure.bobrov.SummaryTask4.util.EntityExtractorTest;
import ua.nure.bobrov.SummaryTask4.util.FieldValidatorTest;
import ua.nure.bobrov.SummaryTask4.web.ControllerServletTest;
import ua.nure.bobrov.SummaryTask4.web.action.account.ChangeLocaleActionTest;
import ua.nure.bobrov.SummaryTask4.web.action.account.EditUserPasswordActionTest;
import ua.nure.bobrov.SummaryTask4.web.action.account.EditUserProfileActionTest;
import ua.nure.bobrov.SummaryTask4.web.action.account.LogOutActionTest;
import ua.nure.bobrov.SummaryTask4.web.action.account.LoginActionTest;
import ua.nure.bobrov.SummaryTask4.web.action.account.RegistrationActionTest;
import ua.nure.bobrov.SummaryTask4.web.filter.ActionAccessFilterTest;
import ua.nure.bobrov.SummaryTask4.web.service.CaptchaVerifyServiceTest;
import ua.nure.bobrov.SummaryTask4.web.service.TripSearchServiceTest;

@RunWith(Suite.class)
@SuiteClasses({ DateParserTest.class, EntityExtractorTest.class, FieldValidatorTest.class,
		CaptchaVerifyServiceTest.class, TripSearchServiceTest.class, LoginActionTest.class, LogOutActionTest.class,
		ChangeLocaleActionTest.class, RegistrationActionTest.class, ControllerServletTest.class, StationDAOTest.class,
		RouteDAOTest.class, RouteItemDAOTest.class, CoachDAOTest.class, TicketDAOTest.class, TripDAOTest.class,
		UserDAOTest.class, UnconfirmedUserDAOTest.class, CoachTypeDAOTest.class, TrainDAOTest.class,
		EditUserPasswordActionTest.class, EditUserProfileActionTest.class, ActionAccessFilterTest.class,
		TripSearchResultBeanTest.class })
public class AllTests {

}
