package ua.nure.bobrov.SummaryTask4.web.filter;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Matchers.*;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.Test;

import ua.nure.bobrov.SummaryTask4.database.entity.User;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;

public class ActionAccessFilterTest {

	@Test
	public void testDoFilter() throws IOException, ServletException {
		ActionAccessFilter filter = new ActionAccessFilter();
		FilterConfig fConfig = mock(FilterConfig.class);
		when(fConfig.getInitParameter(anyString())).thenReturn("action action5");
		filter.init(fConfig);
		HttpServletRequest request = mock(HttpServletRequest.class);
		HttpServletResponse response = mock(HttpServletResponse.class);
		FilterChain chain = mock(FilterChain.class);
		RequestDispatcher requestDispatcher = mock(RequestDispatcher.class);
		HttpSession session = mock(HttpSession.class);
		User user = new User();
		user.setPassword("admin");
		user.setBanned(true);
		when(request.getPathInfo()).thenReturn("/action");
		when(request.getSession(false)).thenReturn(session);
		when(session.getAttribute(RequestProperty.USER)).thenReturn(user);
		when(request.getRequestDispatcher(anyString())).thenReturn(requestDispatcher);
		
		new ActionAccessFilter().doFilter(request, response, chain);

	}
}
