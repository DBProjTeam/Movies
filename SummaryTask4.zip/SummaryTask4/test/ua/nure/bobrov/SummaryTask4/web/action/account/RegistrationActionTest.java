package ua.nure.bobrov.SummaryTask4.web.action.account;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.Test;

import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;

public class RegistrationActionTest {

	@Test
	public void test() throws IOException, ServletException, DatabaseException {
		HttpServletRequest request = mock(HttpServletRequest.class);
		HttpServletResponse response = mock(HttpServletResponse.class);
		HttpSession session = mock(HttpSession.class);
		when(request.getSession()).thenReturn(session);
		when(request.getParameter(RequestProperty.EMAIL)).thenReturn("admin@gmail.com");
		when(request.getParameter(RequestProperty.PASSWORD)).thenReturn("admin");
		RegistrationAction registrationAction = new RegistrationAction();
		registrationAction.execute(request, response);
	}

}
