package ua.nure.bobrov.SummaryTask4.web.action.account;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import ua.nure.bobrov.SummaryTask4.database.DBConnector;
import ua.nure.bobrov.SummaryTask4.database.entity.User;
import ua.nure.bobrov.SummaryTask4.enums.RoleType;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;

public class EditUserProfileActionTest {
	@Mock
	private DataSource dataSourceMock;
	@Mock
	private Connection connection;
	@Mock
	private PreparedStatement mockPreparedStatement;
	@Mock
	private ResultSet mockResultSet;

	@Test
	public void testExecute() throws Exception {
		MockitoAnnotations.initMocks(this);
		Class<DBConnector> clazz = DBConnector.class;
		Field datasource = clazz.getDeclaredField("datasource");
		datasource.setAccessible(true);
		datasource.set(null, (DataSource) dataSourceMock);
		when(dataSourceMock.getConnection()).thenReturn(connection);

		HttpServletRequest request = mock(HttpServletRequest.class);
		HttpServletResponse response = mock(HttpServletResponse.class);
		HttpSession session = mock(HttpSession.class);
		User user = new User();
		user.setPassword("admin");
		user.setRole(RoleType.ADMIN);
		when(request.getSession()).thenReturn(session);
		when(session.getAttribute(RequestProperty.USER)).thenReturn(user);
		when(request.getParameter(RequestProperty.PASSWORD)).thenReturn("admin");
		when(request.getParameter(RequestProperty.PASSWORD2)).thenReturn("newpassword");
		when(connection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
		when(mockPreparedStatement.executeUpdate()).thenReturn(1);
		new EditUserProfileAction().execute(request, response);
	}
}
