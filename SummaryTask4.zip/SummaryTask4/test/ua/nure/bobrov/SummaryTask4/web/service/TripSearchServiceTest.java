package ua.nure.bobrov.SummaryTask4.web.service;

import static org.junit.Assert.assertTrue;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import org.junit.Test;

import ua.nure.bobrov.SummaryTask4.bean.TripDateTimeBean;
import ua.nure.bobrov.SummaryTask4.database.entity.Route;
import ua.nure.bobrov.SummaryTask4.database.entity.RouteItem;
import ua.nure.bobrov.SummaryTask4.database.entity.Station;

public class TripSearchServiceTest {

	@Test
	public void testGetPrice() {
		TripDateTimeBean.TripTime tripTime = new TripDateTimeBean.TripTime();
		tripTime.setMinutes(0);
		tripTime.setHours(1);
		tripTime.setDays(0);
		assertTrue(TripSearchService.getPrice(tripTime, 1.0) == 9);
	}

	@Test
	public void testGetTripDateTimeBean() {
		List<RouteItem> routeItems = new ArrayList<RouteItem>();

		RouteItem routeItem1 = new RouteItem(1, 4, new Time(3600000), new Time(7200000), 1);
		RouteItem routeItem2 = new RouteItem(1, 2, new Time(10000000), new Time(10010000), 2);
		routeItems.add(routeItem1);
		routeItems.add(routeItem2);
		Station beginStation = new Station();
		beginStation.setId(5);
		Station endStation = new Station();
		endStation.setId(7);
		Route route = new Route();
		route.setBeginStation(beginStation);
		route.setEndStation(endStation);
		route.setBeginTime(new Time(1800000));
		route.setEndTime(new Time(20000000));
		assertTrue(TripSearchService.getTripDateTimeBean(routeItems, route, 5, 7,
				new Date(new GregorianCalendar().getTimeInMillis())) != null);
	}

}
