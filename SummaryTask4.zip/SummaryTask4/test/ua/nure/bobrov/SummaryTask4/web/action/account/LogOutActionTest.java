package ua.nure.bobrov.SummaryTask4.web.action.account;

import static org.mockito.Mockito.mock;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.Test;

import ua.nure.bobrov.SummaryTask4.database.entity.User;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;

public class LogOutActionTest {

	@Test
	public void testExecute() throws IOException, ServletException {
		HttpServletRequest request = mock(HttpServletRequest.class);
		HttpServletResponse response = mock(HttpServletResponse.class);
		HttpSession session = mock(HttpSession.class);
		session.setAttribute(RequestProperty.USER, new User());
		LogOutAction logOutAction = new LogOutAction();
		logOutAction.execute(request, response);
	}

}
