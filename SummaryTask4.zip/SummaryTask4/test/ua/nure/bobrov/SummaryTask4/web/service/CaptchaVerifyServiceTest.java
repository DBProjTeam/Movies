package ua.nure.bobrov.SummaryTask4.web.service;

import static org.junit.Assert.*;

import org.junit.Test;

public class CaptchaVerifyServiceTest {

	@Test
	public void testVerifyCaptcha() {
		assertFalse(CaptchaVerifyService.verifyCaptcha("some random captcha"));
	}

}
