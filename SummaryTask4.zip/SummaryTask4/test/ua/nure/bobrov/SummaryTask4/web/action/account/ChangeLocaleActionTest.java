package ua.nure.bobrov.SummaryTask4.web.action.account;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import static org.junit.Assert.*;
import org.junit.Test;

import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;
import ua.nure.bobrov.SummaryTask4.web.Path;
import ua.nure.bobrov.SummaryTask4.web.RequestProperty;
import ua.nure.bobrov.SummaryTask4.web.action.PageData;

public class ChangeLocaleActionTest {

	@Test
	public void testExecute() throws IOException, ServletException, DatabaseException {
		HttpServletRequest request = mock(HttpServletRequest.class);
		HttpServletResponse response = mock(HttpServletResponse.class);
		HttpSession session = mock(HttpSession.class);
		when(request.getParameter(RequestProperty.LANGUAGE)).thenReturn("en");
		when(request.getHeader("Referer")).thenReturn(Path.LOGIN_PAGE);
		when(request.getSession()).thenReturn(session);
		ChangeLocaleAction changeLocaleAction = new ChangeLocaleAction();
		PageData pageData = changeLocaleAction.execute(request, response);
		assertTrue(pageData.getPath().equals(Path.LOGIN_PAGE));
		
	}

}
