package ua.nure.bobrov.SummaryTask4.bean;

import java.sql.Timestamp;
import java.util.ArrayList;

import org.junit.Test;

import ua.nure.bobrov.SummaryTask4.bean.TripDateTimeBean.TripTime;
import ua.nure.bobrov.SummaryTask4.bean.TripSearchResultBean.SeatPriceBean;
import ua.nure.bobrov.SummaryTask4.database.entity.Station;

public class TripSearchResultBeanTest {

	@Test
	public void testAll() {
		TripSearchResultBean bean = new TripSearchResultBean();
		bean.setArrivalStation(new Station());
		bean.setDepartureStation(new Station());
		bean.setTrainNumber("train");
		bean.setTripId(1);
		TripDateTimeBean time = new TripDateTimeBean();
		time.setArrivalDate(new Timestamp(1000));
		time.setDepartureDate(new Timestamp(1000));
		TripTime tripTime = new TripTime();
		tripTime.setDays(1);
		tripTime.setMinutes(1);
		tripTime.setHours(1);
		time.setTripTime(tripTime);
		bean.setTime(time);
		bean.setSeatPriceBeans(new ArrayList<SeatPriceBean>());
		bean.getArrivalStation();
		bean.getCoachTypeNumber();
		bean.getDepartureStation();
		bean.getSeatPriceBeans();
		bean.getTime();
		bean.getTrainNumber();
	}
	
}
