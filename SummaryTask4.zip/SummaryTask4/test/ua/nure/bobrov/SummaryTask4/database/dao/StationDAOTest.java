package ua.nure.bobrov.SummaryTask4.database.dao;

import static org.junit.Assert.*;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import ua.nure.bobrov.SummaryTask4.database.DBConnector;
import ua.nure.bobrov.SummaryTask4.database.entity.Station;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;

public class StationDAOTest {

	@Mock
	private DataSource dataSourceMock;
	@Mock
	private Connection connection;
	@Mock
	private Statement mockStatement;
	@Mock
	private PreparedStatement mockPreparedStatement;

	@Mock
	private ResultSet mockResultSet;
	
	@Before
	public void init() throws IllegalArgumentException, IllegalAccessException, SQLException, NoSuchFieldException, SecurityException {
		MockitoAnnotations.initMocks(this);
		Class<DBConnector> clazz = DBConnector.class;
		Field datasource = clazz.getDeclaredField("datasource");
		datasource.setAccessible(true);
		datasource.set(null, (DataSource)dataSourceMock);
		when(dataSourceMock.getConnection()).thenReturn(connection);
	}
	
	@Test
	public void testFindAll() throws DatabaseException, SQLException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		
		when(connection.createStatement()).thenReturn(mockStatement);
		when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);
		when(mockResultSet.getInt(anyString())).thenReturn(1);
		when(mockResultSet.getString(anyString())).thenReturn("stationName");
		when(mockResultSet.next()).thenReturn(Boolean.TRUE, Boolean.FALSE);
		StationDAO stationDAO = new StationDAO();
		stationDAO.findAll();		
	}
	@Test
	public void testInsert() throws DatabaseException, SQLException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		Station station = new Station();
		station.setId(1);
		station.setName("Name");
		when(connection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
		StationDAO stationDAO = new StationDAO();
		stationDAO.insert(station);	
	}
	@Test
	public void testUpdate() throws DatabaseException, SQLException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		Station station = new Station();
		station.setId(1);
		station.setName("Name");
		when(connection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
		when(mockPreparedStatement.executeUpdate()).thenReturn(1);
		StationDAO stationDAO = new StationDAO();
		assertTrue(stationDAO.update(station));	
	}
	@Test
	public void testDelete() throws DatabaseException, SQLException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		when(connection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
		when(mockPreparedStatement.executeUpdate()).thenReturn(1);
		StationDAO stationDAO = new StationDAO();
		assertTrue(stationDAO.delete(1));	
	}
	@Test
	public void testGetByPK() throws DatabaseException, SQLException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		when(connection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
		when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
		when(mockResultSet.next()).thenReturn(Boolean.TRUE, Boolean.FALSE);
		when(mockResultSet.getInt(anyString())).thenReturn(1);
		when(mockResultSet.getString(anyString())).thenReturn("stationName");
		StationDAO stationDAO = new StationDAO();
		assertTrue(stationDAO.getByPK(1).getName().equals("stationName"));	
	}
	@Test
	public void testGetByName() throws DatabaseException, SQLException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		when(connection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
		when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
		when(mockResultSet.next()).thenReturn(Boolean.TRUE, Boolean.FALSE);
		when(mockResultSet.getInt(anyString())).thenReturn(1);
		when(mockResultSet.getString(anyString())).thenReturn("stationName");
		StationDAO stationDAO = new StationDAO();
		assertTrue(stationDAO.getByName("stationName").getId() == 1);	
	}
	
}
