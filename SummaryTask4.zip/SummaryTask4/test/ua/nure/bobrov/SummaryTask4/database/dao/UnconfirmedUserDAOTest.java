package ua.nure.bobrov.SummaryTask4.database.dao;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import ua.nure.bobrov.SummaryTask4.database.DBConnector;
import ua.nure.bobrov.SummaryTask4.database.entity.UnconfirmedUser;
import ua.nure.bobrov.SummaryTask4.exception.DatabaseException;

public class UnconfirmedUserDAOTest {

	@Mock
	private DataSource dataSourceMock;
	@Mock
	private Connection connection;
	@Mock
	private Statement mockStatement;
	@Mock
	private PreparedStatement mockPreparedStatement;

	@Mock
	private ResultSet mockResultSet;

	@Before
	public void init() throws IllegalArgumentException, IllegalAccessException, SQLException, NoSuchFieldException,
			SecurityException {
		MockitoAnnotations.initMocks(this);
		Class<DBConnector> clazz = DBConnector.class;
		Field datasource = clazz.getDeclaredField("datasource");
		datasource.setAccessible(true);
		datasource.set(null, (DataSource) dataSourceMock);
		when(dataSourceMock.getConnection()).thenReturn(connection);
	}

	@Test
	public void testFindAll() throws DatabaseException, SQLException, NoSuchFieldException, SecurityException,
			IllegalArgumentException, IllegalAccessException {

		when(connection.createStatement()).thenReturn(mockStatement);
		when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);
		when(mockResultSet.getInt(anyString())).thenReturn(1);
		when(mockResultSet.getString(anyString())).thenReturn("");
		when(mockResultSet.next()).thenReturn(Boolean.TRUE, Boolean.FALSE);
		UnconfirmedUserDAO userDAO = new UnconfirmedUserDAO();
		userDAO.findAll();
	}

	@Test
	public void testGetByEmail() throws DatabaseException, SQLException, NoSuchFieldException, SecurityException,
			IllegalArgumentException, IllegalAccessException {
		when(connection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
		when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
		when(mockResultSet.next()).thenReturn(Boolean.TRUE, Boolean.FALSE);
		when(mockResultSet.getInt(anyString())).thenReturn(1);
		when(mockResultSet.getString(anyString())).thenReturn("");
		UnconfirmedUserDAO userDAO = new UnconfirmedUserDAO();
		userDAO.getByEmail("email");
	}
	@Test
	public void testGetByToken() throws DatabaseException, SQLException, NoSuchFieldException, SecurityException,
			IllegalArgumentException, IllegalAccessException {
		when(connection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
		when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
		when(mockResultSet.next()).thenReturn(Boolean.TRUE, Boolean.FALSE);
		when(mockResultSet.getInt(anyString())).thenReturn(1);
		when(mockResultSet.getString(anyString())).thenReturn("");
		UnconfirmedUserDAO userDAO = new UnconfirmedUserDAO();
		userDAO.getByToken("token");
	}
	@Test
	public void testInsert() throws DatabaseException, SQLException, NoSuchFieldException, SecurityException,
			IllegalArgumentException, IllegalAccessException {
		UnconfirmedUser user = new UnconfirmedUser();
		when(connection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
		when(mockPreparedStatement.executeUpdate()).thenReturn(1);
		UnconfirmedUserDAO userDAO = new UnconfirmedUserDAO();
		userDAO.insert(user);
	}
}
