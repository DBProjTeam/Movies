
DROP TABLE IF EXISTS `coach`;

CREATE TABLE `coach` (
  `id_coach` int(11) NOT NULL AUTO_INCREMENT,
  `id_train` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `id_coachtype` int(11) NOT NULL,
  PRIMARY KEY (`id_coach`),
  KEY `fk_train_coach_idx` (`id_train`),
  CONSTRAINT `fk_train_coach` FOREIGN KEY (`id_train`) REFERENCES `train` (`id_train`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `coach` VALUES (1,1,1,1),(2,1,2,2),(3,1,3,3),(4,2,1,4),(5,2,2,3);

DROP TABLE IF EXISTS `coachtype`;

CREATE TABLE `coachtype` (
  `id_coachtype` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `passanger_number` int(11) NOT NULL,
  `picture` varchar(45) DEFAULT NULL,
  `coefficient` double NOT NULL,
  PRIMARY KEY (`id_coachtype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


INSERT INTO `coachtype` VALUES (1,'sleep',36,'sleep.png',1.8),(2,'platz',38,'plaz.png',1.5),(3,'general',64,'general.png',1),(4,'small',2,NULL,1);

DROP TABLE IF EXISTS `route`;

CREATE TABLE `route` (
  `id_route` int(11) NOT NULL AUTO_INCREMENT,
  `id_begin_station` int(11) NOT NULL,
  `id_end_station` int(11) NOT NULL,
  `begin_time` time NOT NULL,
  `end_time` time NOT NULL,
  PRIMARY KEY (`id_route`),
  KEY `fk_station_route_idx` (`id_begin_station`,`id_end_station`),
  KEY `fk_endstation_route_idx` (`id_end_station`),
  CONSTRAINT `fk_beginstation_route` FOREIGN KEY (`id_begin_station`) REFERENCES `station` (`id_station`) ON UPDATE CASCADE,
  CONSTRAINT `fk_endstation_route` FOREIGN KEY (`id_end_station`) REFERENCES `station` (`id_station`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;



INSERT INTO `route` VALUES (7,21,25,'12:00:00','01:00:00'),(8,28,25,'06:00:00','18:00:00');


DROP TABLE IF EXISTS `routeitem`;

CREATE TABLE `routeitem` (
  `id_routeitem` int(11) NOT NULL AUTO_INCREMENT,
  `id_route` int(11) NOT NULL,
  `id_station` int(11) NOT NULL,
  `sequence_number` int(11) NOT NULL,
  `arrival_time` time NOT NULL,
  `departure_time` time NOT NULL,
  PRIMARY KEY (`id_routeitem`),
  KEY `fk_station_routeitem_idx` (`id_station`),
  KEY `fk_route_routeitem_idx` (`id_route`),
  CONSTRAINT `fk_route_routeitem` FOREIGN KEY (`id_route`) REFERENCES `route` (`id_route`) ON UPDATE CASCADE,
  CONSTRAINT `fk_station_routeitem` FOREIGN KEY (`id_station`) REFERENCES `station` (`id_station`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;


INSERT INTO `routeitem` VALUES (22,7,22,1,'16:00:00','16:10:00'),(23,7,23,2,'18:30:00','19:00:00'),(25,7,24,3,'21:00:00','21:10:00'),(26,8,21,1,'11:00:00','12:00:00'),(27,8,29,2,'15:00:00','15:15:00');

DROP TABLE IF EXISTS `station`;

CREATE TABLE `station` (
  `id_station` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id_station`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

INSERT INTO `station` VALUES (24,'Днепропетровск'),(28,'Житомир'),(21,'Киев'),(23,'Кировоград'),(27,'Луцк'),(26,'Львов'),(29,'Полтава'),(25,'Харьков'),(22,'Черкасы');

DROP TABLE IF EXISTS `ticket`;

CREATE TABLE `ticket` (
  `id_ticket` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_trip` int(11) NOT NULL,
  `id_begin_station` int(11) NOT NULL,
  `id_end_station` int(11) NOT NULL,
  `coach_number` int(11) NOT NULL,
  `id_coachtype` int(11) NOT NULL,
  `seat_number` int(11) NOT NULL,
  `price` double NOT NULL,
  `departure_date` datetime NOT NULL,
  `arrival_date` datetime NOT NULL,
  PRIMARY KEY (`id_ticket`),
  KEY `fk_trip_ticket_idx` (`id_trip`),
  KEY `fk_user_ticket_idx` (`id_user`),
  KEY `fk_station1_ticket_idx` (`id_begin_station`),
  KEY `fk_station2_ticket_idx` (`id_end_station`),
  KEY `fk_coachtype_ticket_idx` (`id_coachtype`),
  CONSTRAINT `fk_coachtype_ticket` FOREIGN KEY (`id_coachtype`) REFERENCES `coachtype` (`id_coachtype`) ON UPDATE CASCADE,
  CONSTRAINT `fk_station1_ticket` FOREIGN KEY (`id_begin_station`) REFERENCES `station` (`id_station`) ON UPDATE CASCADE,
  CONSTRAINT `fk_station2_ticket` FOREIGN KEY (`id_end_station`) REFERENCES `station` (`id_station`) ON UPDATE CASCADE,
  CONSTRAINT `fk_trip_ticket` FOREIGN KEY (`id_trip`) REFERENCES `trip` (`id_trip`) ON UPDATE CASCADE,
  CONSTRAINT `fk_user_ticket` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;


INSERT INTO `ticket` VALUES (14,10,5,21,23,1,4,1,58.5,'2016-03-01 12:00:00','2016-03-01 18:30:00'),(15,10,5,21,25,1,4,2,117,'2016-03-01 12:00:00','2016-03-02 01:00:00');



DROP TABLE IF EXISTS `train`;

CREATE TABLE `train` (
  `id_train` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(10) NOT NULL,
  PRIMARY KEY (`id_train`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


INSERT INTO `train` VALUES (1,'1111А'),(2,'156К');


DROP TABLE IF EXISTS `trip`;

CREATE TABLE `trip` (
  `id_trip` int(11) NOT NULL AUTO_INCREMENT,
  `id_train` int(11) NOT NULL,
  `id_route` int(11) NOT NULL,
  `departure_date` date NOT NULL,
  PRIMARY KEY (`id_trip`),
  KEY `fk_route_trip_idx` (`id_route`),
  KEY `fk_train_trip_idx` (`id_train`),
  CONSTRAINT `fk_route_trip` FOREIGN KEY (`id_route`) REFERENCES `route` (`id_route`) ON UPDATE CASCADE,
  CONSTRAINT `fk_train_trip` FOREIGN KEY (`id_train`) REFERENCES `train` (`id_train`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `trip` VALUES (5,2,7,'2016-03-01'),(6,1,8,'2016-03-01');


DROP TABLE IF EXISTS `unconfirmed_user`;

CREATE TABLE `unconfirmed_user` (
  `token` char(36) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(64) NOT NULL,
  `name` varchar(30) NOT NULL,
  `surname` varchar(30) NOT NULL,
  PRIMARY KEY (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) NOT NULL,
  `email` varchar(64) NOT NULL,
  `name` varchar(30) NOT NULL,
  `surname` varchar(30) NOT NULL,
  `id_role` int(11) NOT NULL,
  `banned` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `user` VALUES (9,'admin','admin@gmail.com','admin','admin',0,0),(10,'qwerty888','bobrov@gmail.com','Слава','Бобров',2,0),(11,'manager','manager@gmail.com','Manager','Manager',1,0);


